
function init() {
  this.baseFunctions.init.bind(this)();
  $(`#${this.config.unit} .pac-points`).remove();
  $(`#${this.config.unit}`).append([
    '<div class="ingame-points hidden pac-points">',
    '<span class="red"></span><span class="blue"></span>',
    '</div>',
  ].join(''));
  this.updateScoreDisplay();
}

module.exports = init;
