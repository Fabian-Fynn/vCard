const pd = require('../../modules/game_management/points_display.js');
const BaseGame = require('../base/base.js');
const pacConfig = require('./pac_config.js');

const preload = require('./functions/preload.js');
const create = require('./functions/create.js');
const update = require('./functions/update.js');
const render = require('./functions/render.js');
const init = require('./functions/init.js');

class PacGame extends BaseGame {
  constructor() {
    super();

    // If you want to change the config parts marked with a MARKER
    // go to game_host/config/maze.js and change them there
    // Run 'gulp maze' afterwards
    this.config = $.extend({
      unit: 'pac-canvas', // Unit to which the Unit Switcher Module
      maze: pacConfig.maze,
      mazeSprites: pacConfig.mazeSprites,
      offset: 15, // MARKER_OFFSET
      pacSize: 70, // MARKER_PACSIZE
      lineWidth: 12, // MARKER_LINEW,
      pacSearchObject: pacConfig.pacSearchObject,
      minTeamPlayers: 0,
      roundName: 'Pac',
      numWinningPoints: 3,
    }, this.config);

    this.state = $.extend({
      pac: null,
      mazeGroup: null,
      mazeSprites: [],
    }, this.state);

    this.game = new Phaser.Game(1920, 1080, Phaser.AUTO, this.config.unit, {
      preload: preload.bind(this),
      create: create.bind(this),
      update: update.bind(this),
      render: render.bind(this),
      init: init.bind(this),
    });
  }

  end() {
    clearInterval(this.state.pac.chaseInterval);
    if (this.state.pac.respawnTimeout !== false) {
      clearTimeout(this.state.pac.respawnTimeout);
    }

    setTimeout(() => {
      pd.displayRoundPoints('pac-canvas');
    }, 1000);

    super.end();
  }
}

module.exports = PacGame;
