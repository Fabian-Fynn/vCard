
function init() {
  this.baseFunctions.init.bind(this)();
  $(`#${this.config.unit} .snake-points`).remove();
  $(`#${this.config.unit}`).append([
    '<div class="ingame-points hidden snake-points">',
    '<span class="red"></span><span class="blue"></span>',
    '</div>',
  ].join(''));
}

module.exports = init;
