function updateMaxerl() {
  const state = this.state;
  for (let i = 0; i < state.maxerl.length; i++) {
    if (state.maxerl[i].state.current !== state.maxerl[i].state.dead) {
      this.game.physics.arcade.collide(
        state.maxerl[i].sprite,
        state.mazeGroup,
        state.maxerl[i].slideCollide.bind(state.maxerl[i])
      );
    } else {
      this.game.physics.arcade.collide(state.maxerl[i].sprite, state.mazeGroup);
    }
    state.maxerl[i].update();
  }
  state.pac.update();
}

function update() {
  this.baseFunctions.update.bind(this)();

  updateMaxerl.bind(this)();

  for (let idx in this.state.endzones) {
    this.state.endzones[idx].update();
  }
}


module.exports = update;
