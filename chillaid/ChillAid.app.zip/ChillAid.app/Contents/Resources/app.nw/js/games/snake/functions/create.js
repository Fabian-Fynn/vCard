const Snake = require('../entities/snake.js');

function create() {
  // Create snakes

  if (this.teams.red.members.length <= 2 || this.teams.red.members.length <= 2) {
    this.baseFunctions.create.bind(this)({
      red: [{ x: 425, y: 380 }, { x: 320, y: 380 }, { x: 215, y: 380 }],
      blue: [{ x: 1495, y: 380 }, { x: 1600, y: 380 }, { x: 1705, y: 380 }],
    });
    this.game.add.tileSprite(0, this.game.height - 50, 1920, 1000, 'spikes');
    this.state.snakeGroup = this.game.add.physicsGroup();
    for (let i = 0; i < this.config.randomSnakes.length; i++) {
      this.state.snakes.push(new Snake(this.config.randomSnakes[i]));
    }
  } else {
    this.baseFunctions.create.bind(this)({
      red: [{ x: 0, y: 0 }, { x: 425, y: 380 }, { x: 320, y: 380 }, { x: 215, y: 380 }],
      blue: [{ x: 0, y: 0 }, { x: 1495, y: 380 }, { x: 1600, y: 380 }, { x: 1705, y: 380 }],
    }, 1);
    this.game.add.tileSprite(0, this.game.height - 50, 1920, 1000, 'spikes');
    this.state.snakeGroup = this.game.add.physicsGroup();
    this.config.snakes[0].controller = global.controllerManager.get(this.teams.red.members[0]);
    this.config.snakes[1].controller = global.controllerManager.get(this.teams.blue.members[0]);
    for (let i = 0; i < 2; i++) {
      this.state.snakes.push(new Snake(this.config.snakes[i]));
    }
    this.state.food = this.game.add.sprite(-100, -100, 'food');
    this.game.physics.arcade.enable(this.state.food);
    this.state.food.body.immovable = false;
    this.state.food.body.collideWorldBounds = true;
    this.repositionFood();
  }
  this.checkWin();
}

module.exports = create;
