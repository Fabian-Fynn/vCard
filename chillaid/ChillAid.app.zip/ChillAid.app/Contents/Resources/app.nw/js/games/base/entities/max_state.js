const utils = require('../../../modules/utils.js');

class MaxState {
  constructor() {
    this.stand = {
      name: 'Standing',
    };

    this.run = {
      name: 'Running',
    };

    this.jump = {
      name: 'Jumping',
    };

    this.fall = {
      name: 'Falling',
    };

    this.slide = {
      name: 'Sliding',
    };

    this.land = {
      name: 'Landing',
    };

    this.shove = {
      name: 'Shoving',
    };

    this.dead = {
      name: 'Dead',
    };

    this.dead.possibleStates = [this.stand];
    this.jump.possibleStates = [this.fall, this.dead, this.slide];
    this.fall.possibleStates = [this.land, this.dead, this.slide];
    this.slide.possibleStates = [this.land, this.stand, this.jump, this.dead];
    this.stand.possibleStates = [this.run, this.jump, this.fall, this.dead, this.shove];
    this.land.possibleStates = [this.stand, this.run, this.dead];
    this.run.possibleStates = [
      this.stand, this.run, this.jump, this.fall, this.dead, this.c, this.shove,
    ];
    this.shove.possibleStates = [this.stand, this.dead];

    this.current = this.stand;
  }

  change(state) {
    if (utils.contains.call(this.current.possibleStates, state)) {
      this.current = state;
      return true;
    }
    return false;
  }

  is(state) {
    return this.current === state;
  }
}

module.exports = MaxState;
