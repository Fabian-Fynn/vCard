var APP = window.APP || {};
APP.Games = APP.Games || {};
APP.Games.Pac = APP.Games.Pac || {};
APP.Games.Pac.functions = APP.Games.Pac.functions || {};

APP.Games.Pac.functions.render = (function(){

  function render() {
    APP.BaseGame.render();
    var state = APP.GameManager().currentGame.gameState;
    for(var i = 0; i < state.mazeSprites.length; i++) {
      APP.currentlyRunningGame.debug.body(state.mazeSprites[i]);
    }
  }

  return render;
})();