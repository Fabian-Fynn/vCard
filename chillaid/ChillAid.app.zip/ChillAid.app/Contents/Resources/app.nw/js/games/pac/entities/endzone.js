class Endzone {
  constructor(config) {
    this.parent = config.parent;
    this.c = config.c;
    this.t = config.t;
    this.x = config.x;
    this.y = config.y;
    this.w = config.w;
    this.h = config.h;

    const img = this.parent.game.add.bitmapData(config.w, config.h);
    img.ctx.beginPath();
    img.ctx.rect(0, 0, config.w, config.h);
    img.ctx.fillStyle = config.c;
    img.ctx.fill();

    this.parent.game.add.sprite(config.x, config.y, img);
  }

  update() {
    if (this.parent.state.pac.respawning === true) {
      return;
    }
    const x = this.parent.state.pac.sprite.x;
    const y = this.parent.state.pac.sprite.y;
    if (x >= this.x && x <= this.x + this.w &&
      y >= this.y && y <= this.y + this.h) {
      this.parent.state.pac.respawning = true;
      global.gm.pointManager.addPoint({
        team: this.t,
        round: this.parent.config.roundName,
      });
      this.parent.updateScoreDisplay();
      const winningTeam = global.gm.pointManager.teamHasXRoundPoints(
        this.parent.config.roundName,
        this.parent.config.numWinningPoints
      );
      if (winningTeam !== false) {
        this.parent.state.pac.destroy(true);
        global.gm.pointManager.addPoint({
          team: winningTeam,
          game: true,
        });
        this.parent.updateScoreDisplay();
        this.parent.end();
      } else {
        this.parent.state.pac.destroy(false);
      }
    }
  }
}

module.exports = Endzone;
