const utils = require('../../../modules/utils.js');

function createPacSprite() {
  const frames = 5;
  const deathFrames = 10;
  const img = this.game.add.bitmapData(
    this.config.pacSize * (frames + deathFrames),
    this.config.pacSize
  );

  function drawIteration(image, idx, opening) {
    const cx = this.config.pacSize / 2 + this.config.pacSize * idx;
    const cy = this.config.pacSize / 2;
    const curveStart = utils.rotateVec(cx, cy, cx + this.config.pacSize / 2, cy, opening * Math.PI);
    image.ctx.beginPath();
    image.ctx.moveTo(curveStart[0], curveStart[1]);
    image.ctx.lineTo(cx, cy);
    image.ctx.lineTo(curveStart[0], this.config.pacSize - curveStart[1]);
    image.ctx.arc(cx, cy, this.config.pacSize / 2, opening * Math.PI, (2 - opening) * Math.PI);
    image.ctx.fillStyle = 'white';
    image.ctx.fill();
  }

  for (let i = 0; i < frames; i++) {
    drawIteration.bind(this)(img, i, 0.25 * (i / frames));
  }
  for (let i = frames; i < frames + deathFrames; i++) {
    drawIteration.bind(this)(img, i, 0.6 * (i / deathFrames));
  }

  return img.canvas.toDataURL();
}

function preload() {
  this.baseFunctions.preload.bind(this)();
  this.game.load.spritesheet(
    'pac',
    createPacSprite.bind(this)(),
    this.config.pacSize,
    this.config.pacSize
  );
}

module.exports = preload;
