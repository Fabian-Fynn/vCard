const utils = require('../../../../modules/utils.js');

class BaseBlock {
  constructor(options) {
    this.parentState = options.parent.state;
    this.game = options.parent.game;
    this.team = options.team;
    this.down = false;
    this.sprites = [];
    this.createConfig();


    if(this.parentState.slots[this.team].length === 0){
      this.parentState.slots[this.team] = $.extend([], this.config.slots[this.team]);
    }

    // Do in subtype constructor
    // this.createSprite();
    // this.rotate(utils.ranInt(0, 3));
  }

  createConfig() {
    this.config = {
      y: -200,
      spriteScale: 0.5,
      slots: [[], []],
      startVelocity: 400,
      blockWidth: 0,
    };

    this.config.blockWidth = 100 * this.config.spriteScale;
    const xSlots = 1900 / this.config.blockWidth;
    const slots = Array.apply(null, { length: xSlots }).map(Number.call, Number);

    this.config.slots.red = slots.splice(0, xSlots / 2);
    this.config.slots.blue = slots;

    // for(var i = 0; i < this.config.slots.red.length; i++) {
    //   let x = (this.config.slots.red[i] * this.config.blockWidth) + this.config.blockWidth / 2;
    //   if(this.config.slots.red[i] > 18) {
    //     x += 20;
    //   }
    //   const graphics = this.game.add.graphics(x, 0);
    //   graphics.lineStyle(2, 0xff0000);
    //   graphics.moveTo(0, 0);
    //   graphics.lineTo(0, 1080);
    // }
    // for(var i = 0; i < this.config.slots.blue.length; i++) {
    //   let x = (this.config.slots.blue[i] * this.config.blockWidth) + this.config.blockWidth / 2;
    //   if(this.config.slots.blue[i] > 18) {
    //     x += 20;
    //   }
    //   const graphics = this.game.add.graphics(x, 0);
    //   graphics.lineStyle(2, 0x0000ff);
    //   graphics.moveTo(0, 0);
    //   graphics.lineTo(0, 1080);
    // }
  }

  getBounds() {
    let ret = {};
    if(this.sprites.length === 1) {
      ret = {
        top: this.sprites[0].top,
        bottom: this.sprites[0].bottom,
        left: this.sprites[0].left,
        right: this.sprites[0].right,
        center: {},
      };
    } else {
      ret = {
        top: this.sprites.reduce((prev, cur) => { return ((cur.top < prev.top) ? cur.top : prev.top) }),
        bottom: this.sprites.reduce((prev, cur) => { return ((cur.bottom > prev.bottom) ? cur.bottom : prev.bottom) }),
        left: this.sprites.reduce((prev, cur) => { return ((cur.left < prev.left) ? cur.left : prev.left) }),
        right: this.sprites.reduce((prev, cur) => { return ((cur.right > prev.right) ? cur.right : prev.right) }),
        center: {},
      };
    }
    ret.center.x = ret.left + Math.abs(ret.right - ret.left) / 2;
    ret.center.y = ret.top + Math.abs(ret.top - ret.bottom) / 2;
    return ret;
  }

  keepInAreaBounds() {
    const currentBounds = this.getBounds();
    let left = this.team === 'red' ? 0 : 970;
    let right = this.team === 'red' ? 950 : 1920;

    if (currentBounds.left < left) {
      this.move(Math.abs(currentBounds.left - left));
    } else if (currentBounds.right > right) {
      this.move(-1 * Math.abs(currentBounds.right - right));
    } else if (currentBounds.left % this.blockWidth !== 0) {

    }
  }

  move(x) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].x += x;
    }
  }

  setSpeed(velocity) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].body.velocity.y = velocity;
    }
  }

  createSprite(sprites) {
    for (let i = 0; i < sprites.length; i++) {
      const spriteConfig = sprites[i];
      const x = spriteConfig.vectors[0][0] * this.config.blockWidth + this.config.x;
      const y = spriteConfig.vectors[0][1] * this.config.blockWidth + this.config.y;

      const sprite = this.game.add.sprite(x, y, spriteConfig.name);
      sprite.block = this;

      sprite.anchor.setTo(0.5, 0.5);

      sprite.outOfBoundsKill = true;
      sprite.checkWorldBounds = true;
      sprite.scale.x = this.config.spriteScale;
      sprite.scale.y = this.config.spriteScale;

      this.game.physics.arcade.enable(sprite);
      sprite.body.mass = 0;
      sprite.body.immovable = false;
      sprite.body.collideWorldBounds = false;

      this.sprites.push(sprite);
      this.parentState.blockGroups.push(sprite);
    }
    this.setSpeed(this.config.startVelocity);
  }
}

module.exports = BaseBlock;
