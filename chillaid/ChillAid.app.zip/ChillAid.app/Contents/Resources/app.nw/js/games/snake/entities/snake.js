const utils = require('../../../modules/utils.js');

const velocityX = [0, 1, 0, -1];
const velocityY = [-1, 0, 1, 0];

function applyConfigToSprite(config) {
  config.game.physics.arcade.enable(this);
  config.sn.add(this);
  this.tint = config.tint;
  this.scale.setTo(config.scale, config.scale);
  this.body.direction = config.dir;
  this.body.velocity.x = config.velX;
  this.body.velocity.y = config.velY;
  this.angle = config.ang;
  this.anchor.setTo(config.anc, config.anc);
}

class Snake {
  constructor(config) {
    const spriteSize = config.spriteScale * 100;
    const dirMultiplier = config.direction === 1 ? -1 : 1;

    this.velocity = 150; // Pixels per second
    // velocity / 60 = px per tick | spriteSize / px per tick = turnTick
    // Make sure this is a round number
    this.turnTick = spriteSize / (this.velocity / 60);
    this.nextTurn = null;
    this.controller = config.controller;
    this.parent = config.parent;

    const spriteConfig = {
      game: this.parent.game,
      dir: config.direction,
      velX: velocityX[config.direction] * this.velocity,
      velY: velocityY[config.direction] * this.velocity,
      ang: config.direction * 90,
      anc: 0.5,
      tint: config.color,
      scale: config.spriteScale,
      sn: this.parent.state.snakeGroup,
    };

    // Add snake head
    const snake = this.parent.game.add.sprite(config.x, config.y, 'snake', 0);
    applyConfigToSprite.bind(snake)(spriteConfig);

    // Torso
    snake.torso = [];
    for (let i = 1; i < config.length + 1; i++) {
      const x = config.x + i * spriteSize * dirMultiplier;
      const torsoBlock = this.parent.game.add.sprite(x, config.y, 'snake', 1);
      applyConfigToSprite.bind(torsoBlock)(spriteConfig);
      snake.torso.push(torsoBlock);
    }

    // Tail
    const lastTBlock = snake.torso[snake.torso.length - 1];
    const x = lastTBlock.body.position.x + spriteSize * dirMultiplier;
    const tail = this.parent.game.add.sprite(x, lastTBlock.body.position.y, 'snake', 2);
    applyConfigToSprite.bind(tail)(spriteConfig);
    snake.tail = tail;

    this.parent.state.snakeGroup.setAll('body.immovable', true);
    this.sprite = snake;
    if (this.controller === 'random') {
      this.randomMoveInterval = setInterval(() => {
        const dir = ['up', 'down', 'left', 'right'][utils.ranInt(0, 3)];
        this.setNextTurn(dir);
      }, 750);
    } else {
      this.controller.emitter.on('strong_dir_change', (d) => { this.setNextTurn(d); });
    }
  }

  removeInterval() {
    if (typeof this.randomMoveInterval !== 'undefined') {
      clearInterval(this.randomMoveInterval);
    }
  }

  setNextTurn(dir) {
    const curDir = this.sprite.body.direction;

    switch (true) {
      case ([1, 3].includes(curDir) && dir === 'up'): this.nextTurn = 0; break;
      case ([0, 2].includes(curDir) && dir === 'right'): this.nextTurn = 1; break;
      case ([1, 3].includes(curDir) && dir === 'down'): this.nextTurn = 2; break;
      case ([0, 2].includes(curDir) && dir === 'left'): this.nextTurn = 3; break;
      default: break;
    }
  }

  turn() {
    // Tail
    const lastTorsoBlock = this.sprite.torso[this.sprite.torso.length - 1];
    this.sprite.tail.body.direction = lastTorsoBlock.body.direction;
    this.sprite.tail.body.velocity.x = lastTorsoBlock.body.velocity.x;
    this.sprite.tail.body.velocity.y = lastTorsoBlock.body.velocity.y;
    this.sprite.tail.angle = lastTorsoBlock.body.direction * 90;

    // Torso
    for (let i = this.sprite.torso.length - 1; i > 0; i--) {
      this.sprite.torso[i].body.direction = this.sprite.torso[i - 1].body.direction;
      this.sprite.torso[i].body.velocity.x = this.sprite.torso[i - 1].body.velocity.x;
      this.sprite.torso[i].body.velocity.y = this.sprite.torso[i - 1].body.velocity.y;
    }

    // First Torso Block inherits state from head
    this.sprite.torso[0].body.direction = this.sprite.body.direction;
    this.sprite.torso[0].body.velocity.x = this.sprite.body.velocity.x;
    this.sprite.torso[0].body.velocity.y = this.sprite.body.velocity.y;

    // Head responds to User Input
    if (this.nextTurn !== null) {
      this.sprite.body.direction = this.nextTurn;
      this.sprite.angle = this.nextTurn * 90;
      this.sprite.body.velocity.x = velocityX[this.nextTurn] * this.velocity;
      this.sprite.body.velocity.y = velocityY[this.nextTurn] * this.velocity;
    }
  }

  checkWrap() {
    // Add all blocks of the snake to snakeBlocks
    const snakeBlocks = [this.sprite].concat(this.sprite.torso).concat([this.sprite.tail]);

    // Check each block if it is out of world bound wrap if needed
    for (let y = 0; y < snakeBlocks.length; y++) {
      const element = snakeBlocks[y];

      if (element.body.x >= this.parent.game.width && element.body.direction === 1) {
        element.body.x = -25;
      }

      if (element.body.x <= -25 && element.body.direction === 3) {
        element.body.x = this.parent.game.width + 25;
      }

      if (element.body.y >= this.parent.game.height && element.body.direction === 2) {
        element.body.y = -25;
      }

      if (element.body.y <= -25 && element.body.direction === 0) {
        element.body.y = this.parent.game.height + 25;
      }
    }
  }

  poison() {
    // Give tail properties of last torso block and delete that
    const lastTorsoBlock = this.sprite.torso[this.sprite.torso.length - 1];

    if (this.sprite.torso.length > 1) {
      this.sprite.tail.body.direction = lastTorsoBlock.body.direction;
      this.sprite.tail.body.velocity.x = lastTorsoBlock.body.velocity.x;
      this.sprite.tail.body.velocity.y = lastTorsoBlock.body.velocity.y;
      this.sprite.tail.angle = lastTorsoBlock.body.direction * 90;
      this.sprite.tail.body.x = lastTorsoBlock.body.x;
      this.sprite.tail.body.y = lastTorsoBlock.body.y;

      this.sprite.torso.pop();
      lastTorsoBlock.destroy();
    }
  }

  update() {
    if (this.parent.state.tickCounter % this.turnTick === 0) {
      this.turn();
      this.checkWrap();
    }
  }
}

module.exports = Snake;
