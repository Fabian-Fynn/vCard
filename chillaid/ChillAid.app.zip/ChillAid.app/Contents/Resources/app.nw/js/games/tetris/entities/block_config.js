const config = {
  types: [
    { name: 'O',
      sprites: [
        { name: '2x2-block', vectors: [ [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0] ], offsetVectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 1], [0, 0, 1] ] }
      ]
    },

    { name: 'L',
      sprites: [
        { name: 'three-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0, 3] ], offsetVectors: [ [0, 0, 0], [-3, 0, 1], [-1, -3, 1], [0, -1, 1] ] },
        { name: 'two-block', vectors: [ [2, 2, 1], [-2, 2, 2], [-2, -2, 3], [2, -2, 4] ], offsetVectors: [ [-2, 0, 0], [-1, -2, 1], [0, -1, 1], [0, 0,1] ]}
      ],
      HSL: 0.9
    },

    { name: 'LL',
      sprites: [
        { name: 'three-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0, 3] ], offsetVectors: [ [0, 0, 0], [-3, 0, 1], [-1, -3, 2], [0, -1, 3] ] },
        { name: 'two-block', vectors: [ [2, 0, 1], [0, 2, 2], [-2, 0, 3], [2, -1, 4] ], offsetVectors: [ [-2, 0, 0], [-1, -2, 1], [0, -1, 1], [0, 0,1] ]}
      ],
        HSL: 0.5
    },

    { name: 'T'
      , sprites: [
        { name: 'three-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0, 3] ], offsetVectors: [ [0, 0, 0], [-3, 0, 1], [-1, -3, 2], [0, -1, 3] ] },
        { name: 'two-block', vectors: [ [2, 1, 1], [-1, 2, 2], [-2, -1, 3], [1, -1, 4] ], offsetVectors: [ [-2, 0, 0], [-1, -2, 1], [0, -1, 1], [0, 0,1] ] }
      ],
      HSL: 0.6
    },

    { name: 'I',
      sprites: [
        { name: 'four-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 0], [0, 0,1] ], offsetVectors: [ [0, 0, 0], [-4, 0, 1], [0, 0, 0], [-4, 0, 3] ]  }
      ],
      HSL: 0.4
    },

    { name: 'Z',
      sprites: [
        { name: 'two-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0, 3] ], offsetVectors: [ [0, 0, 0], [-2, 0, 1], [-1, -2, 2], [0, -1, 3] ] },
        { name: 'two-block', vectors: [ [1, -1, 0], [1, 1, 1], [-1, 1, 2], [-1, -1, 3] ], offsetVectors: [ [0, 0, 0], [-2, 0, 1], [-1, -2, 1], [0, -1, 1] ] }
      ],
      HSL: 0.8
    },

    { name: 'ZZ',
      sprites: [
        { name: 'two-block', vectors: [ [0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0,3] ], offsetVectors: [ [0, 0, 0], [-2, 0, 1], [-1, -2, 2], [0, -1, 3] ] },
        { name: 'two-block', vectors: [ [1, 1, 0], [-1, 1, 1], [-1, -1, 2], [1, -1, 3] ], offsetVectors: [ [0, 0, 0], [-2, 0, 1], [-1, -2, 1], [0, -1, 1] ] }
      ],
      HSL: 0.1
    },
  ],
  y: -100,
  spriteScale: 0.5,
  slots: [[], []],
  fixedType: false,
  blockWidth: 0
}


config.blockWidth = 100 * config.spriteScale;
const xSlots = 1500 / config.blockWidth;
const slots = Array.apply(null, {length: xSlots}).map(Number.call, Number);

config.slots[0] = slots.splice( 0, xSlots / 2 );
config.slots[1] = slots;

module.exports = config;
