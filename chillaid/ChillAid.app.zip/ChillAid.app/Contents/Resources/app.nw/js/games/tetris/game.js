const BaseGame = require('../base/base.js');
const pd = require('../../modules/game_management/points_display.js');

const preload = require('./functions/preload.js');
const create = require('./functions/create.js');
const update = require('./functions/update.js');
const render = require('./functions/render.js');
const init = require('./functions/init.js');

const blocks = require('./entities/blocksArray.js');

const utils = require('../../modules/utils.js');

class TetrisGame extends BaseGame {
  constructor() {
    super();

    this.config = $.extend({
      unit: 'tetris-canvas',
      parent: this,
      spawnCountdownPauseBase: 30,
      spawnCountdownBase: 15,
      velocityBase: 100,
      curVelocityBase: 400,
      pointsTick: 10,
      slots: [{ red: [], blue: [] }],
      roundName: 'Tetris',
    }, this.config);

    const xSlots = 1900 / 50;
    const slots = Array.apply(null, { length: xSlots }).map(Number.call, Number);

    this.config.slots.red = slots.splice(0, xSlots / 2);
    this.config.slots.blue = slots;

    this.state = $.extend({
      blocks: {
        red: [],
        blue: [],
      },
      spawnCountdownPause: this.config.spawnCountdownPauseBase,
      spawnCountdown: {
        red: this.config.spawnCountdownBase,
        blue: this.config.spawnCountdownBase,
      },
      slots: {
        red: $.extend([], this.config.slots.red),
        blue: $.extend([], this.config.slots.blue),
      },
      removedSlots: {
        red: [],
        blue: [],
      },
      sinkVelocity: this.config.velocityBase / 2,
      blockSprites: {
        red: {
          falling: [],
          sinking: [],
        },
        blue: {
          falling: [],
          sinking: [],
        },
      },
      blocksGroup: null,
      lastSpawned: {
        red: null,
        blue: null,
      },
    }, this.state);

    this.game = new Phaser.Game(1920, 1080, Phaser.AUTO, this.config.unit, {
      preload: preload.bind(this),
      create: create.bind(this),
      update: update.bind(this),
      render: render.bind(this),
      init: init.bind(this),
    });
    this.ended = false;
    this.debugGraphics = [];
  }

  removeSlot(team, idx) {
    const i = this.state.slots[team].indexOf(idx);
    if (i !== -1) {
      const slot = this.state.slots[team].splice(i, 1)[0];
      this.state.removedSlots[team].push(slot);
    }
  }

  spawnNewBlock(team) {
    if (this.state.slots[team].length < 7) {
      this.state.spawnCountdownPause = this.config.spawnCountdownPauseBase;
      const addedSlots = this.state.removedSlots[team].splice(0, 7);
      this.state.slots[team] = this.state.slots[team].concat(addedSlots);
      this.state.slots[team].sort();
    }

    const index = utils.ranInt(0, this.state.slots[team].length - 1);
    const slot = this.state.slots[team][index];
    const freeWidth = this.freeSlotsAt(index, team);

    const fittingBlocks = blocks[freeWidth - 1];
    const rb = fittingBlocks[utils.ranInt(0, fittingBlocks.length - 1)];
    const config = { team, slot, parent: this, fixedRotation: rb.fixRotation };
    this.state.blocks[team].push(new rb.Block(config));
    // this.drawFreeSlots();
  }

  freeSlotsAt(index, team) {
    const slot = this.state.slots[team][index];
    let freeWidth = 1;
    let lastSlot = slot;
    for (let i = index + 1; i < this.state.slots[team].length; i++) {
      if (this.state.slots[team][i] - lastSlot !== 1) {
        break;
      }
      lastSlot = i;
      freeWidth++;
    }
    return freeWidth > 4 ? 4 : freeWidth;
  }

  drawFreeSlots() {
    for (let i = 0; i < this.debugGraphics.length; i++) {
      this.debugGraphics[i].destroy();
    }

    for (let i = 0; i < this.state.slots.red.length; i++) {
      let x = (this.state.slots.red[i] * 50) + 50 / 2;
      if (this.state.slots.red[i] > 18) {
        x += 20;
      }
      this.addDebugLine(x, 0xff0000);
    }
    for (let i = 0; i < this.state.slots.blue.length; i++) {
      let x = (this.state.slots.blue[i] * 50) + 50 / 2;
      if (this.state.slots.blue[i] > 18) {
        x += 20;
      }
      this.addDebugLine(x, 0x0000ff);
    }
  }

  addDebugLine(x, col) {
    const graphics = this.game.add.graphics(x, 0);
    graphics.lineStyle(2, col);
    graphics.moveTo(0, 0);
    graphics.lineTo(0, 1080);
    this.debugGraphics.push(graphics);
  }

  end() {
    setTimeout(() => {
      pd.displayRoundPoints('tetris-canvas', 50);
    }, 1000);

    super.end();
  }
}

module.exports = TetrisGame;
