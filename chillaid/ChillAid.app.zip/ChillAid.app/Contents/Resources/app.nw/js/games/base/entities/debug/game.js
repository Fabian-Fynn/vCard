const BaseGame = require('../base/base.js');

class DebugGame extends BaseGame {
  constructor() {
    super();

    this.config = $.extend({
      unit: 'debug-canvas',
      minTeamPlayers: 0,
    }, this.config);

    this.state = $.extend({

    }, this.state);

    this.game = new Phaser.Game(1920, 1080, Phaser.AUTO, this.config.unit, {
      preload: this.preload.bind(this),
      create: this.create.bind(this),
      update: this.update.bind(this),
      render: this.render.bind(this),
      init: this.init.bind(this),
    });
  }
}

DebugGame.prototype.preload = require('./functions/preload.js');

DebugGame.prototype.create = require('./functions/create.js');

DebugGame.prototype.update = require('./functions/update.js');

DebugGame.prototype.render = require('./functions/render.js');

DebugGame.prototype.init = require('./functions/init.js');

module.exports = DebugGame;
