
function preload() {
  this.baseFunctions.preload.bind(this)();
}

module.exports = preload;
