
function preload() {
  this.baseFunctions.preload.bind(this)();

  this.game.load.image('bg', 'assets/snake/background.png');
  this.game.load.image('spikes', 'assets/snake/spikes.png');
  this.game.load.image('food', 'assets/snake/food.png');
  this.game.load.spritesheet('snake', 'assets/snake/snake.png', 100, 100, 3);
}

module.exports = preload;
