const cs = require('../../modules/frontend/canvas_scaler.js');
const us = require('../../modules/frontend/unit_switcher.js');
const tm = require('../../modules/game_management/team_manager.js');
const Max = require('./entities/max.js');

function addMaxerl(positions, pad) {
  const nameStyle = {
    font: 'normal 22px Lato',
    fill: '#000',
    boundsAlignH: 'center',
    boundsAlignV: 'middle',
  };

  for (let idx in this.teams) {
    for (let y = pad; y < this.teams[idx].members.length; y++) {

      const maxX = positions[idx][y].x;
      const maxY = positions[idx][y].y;
      const maxDir = idx === 'red' ? 1 : 0;
      const name = global.controllerManager.get(this.teams[idx].members[y]).state.name;
      const maxConfig = {
        collideEverywhere: true,
        x: maxX,
        y: maxY,
        direction: maxDir,
        controller: global.controllerManager.get(this.teams[idx].members[y]),
        parent: this,
        team: this.teams[idx],
        name: this.game.add.text(maxX, maxY, name, nameStyle),
      };
      const max = new Max(maxConfig);
      this.state.maxerl.push(max);
      max.controller.emitter.on('disconnect', () => {
        this.state.maxerl.splice(this.state.maxerl.indexOf(max), 1);
        max.sprite.destroy();
        max.name.destroy();
        max.controller.emitter.removeAllListeners('disconnect');
        if (!tm.teamMinimumReached(1)) {
          global.gm.gameQueue = [];
          this.end();
        }
      });
    }
  }
}

class BaseGame {
  constructor() {
    const timing = {
      us: 1000, // unit switcher animation time
      fc: 500, // first card
      cd: 3000, // card duration
      ca: 3, // amount of cards
    };
    this.baseFunctions = {
      create(maxerlPos, maxerlPad = 0) {
        this.game.add.sprite(0, 0, 'bg');
        this.state.maxGroup = this.game.add.group();
        this.game.stage.disableVisibilityChange = true;
        this.game.paused = true;
        setTimeout(() => {
          this.game.paused = false;
          $(`#${this.config.unit} .ingame-menu`).removeClass('hidden');
          $(`#${this.config.unit} .ingame-points`).removeClass('hidden');
          this.afterCountdown();
          // time out short before splash is hidden to prevent
          // buggy looking game showing
        }, (timing.us + timing.fc + timing.cd * 3) - 100);
        this.game.physics.startSystem(Phaser.Physics.ARCADE);
        addMaxerl.bind(this)(maxerlPos, maxerlPad);
      },
      init() {
        cs.init($(`#${this.config.unit} canvas`));
        $(`#${this.config.unit} .points`).removeClass('visible');
        us.switchToUnit(this.config.unit);

        setTimeout(() => { // Wait untill unit switcher is finished
          $(`#${this.config.unit} .splash`).addClass('loading');
          $(`#${this.config.unit} .ingame-menu`).addClass('hidden');
          $(`#${this.config.unit} .ingame-points`).addClass('hidden');

          setTimeout(() => {
            $(`#${this.config.unit} .splash`).addClass('step-1');
          }, timing.fc);
          setTimeout(() => {
            $(`#${this.config.unit} .splash`).addClass('step-2').removeClass('step-1');
          }, timing.fc + timing.cd);
          setTimeout(() => {
            $(`#${this.config.unit} .splash`).addClass('step-3').removeClass('step-2');
          }, timing.fc + timing.cd * 2);
          setTimeout(() => {
            $(`#${this.config.unit} .splash`).removeClass('step-3');
            $(`#${this.config.unit} .splash`).addClass('hidden');
          }, timing.fc + timing.cd * 3);
        }, timing.us);
      },
      preload() {
        this.game.load.image('bg', 'assets/snake/background.png');
        this.game.load.spritesheet('max_hat', 'assets/max/max_hat.png', 100, 100);
        this.game.load.spritesheet('max_pony', 'assets/max/max_pony.png', 100, 100);
        this.game.load.spritesheet('max_scarf', 'assets/max/max_scarf.png', 100, 100);
        this.game.load.spritesheet('max_shorts', 'assets/max/max_shorts.png', 100, 100);
      },
      render() {
        for (let i = 0; i < this.state.maxerl.length; i++) {
          // this.game.debug.body(this.state.maxerl[i].sprite);
        }
        // if(this.state.blocks){
        //   for (let i = 0; i < this.state.blocks.length; i++) {
        //      for (let j = 0; j < this.state.blocks[i].sprites.length; j++) {
        //       this.game.debug.body(this.state.blocks[i].sprites[j]);
        //      }
        //   }
        // }
      },
      update() {
      },
    };
    this.config = {

    };
    this.state = {
      game: null,
      maxerl: [],
      maxGroup: null,
      countdown: 212,
      controllerStates: null,
      teams: null,
      tickCounter: 0,
    };
    this.teams = tm.getTeams();
    this.scoreDisplay = null;
  }

  updateScoreDisplay() {
    if (this.scoreDisplay === null) {
      this.scoreDisplay = {
        points: {
          red: $(`#${this.config.unit} .points .red`),
          blue: $(`#${this.config.unit} .points .blue`),
        },
        ingamePoints: {
          red: $(`#${this.config.unit} .ingame-points .red`),
          blue: $(`#${this.config.unit} .ingame-points .blue`),
        },
      };
    };
    const points = global.gm.pointManager.getRoundPoints(this.config.roundName);
    for (let idx in points) {
      this.scoreDisplay.points[idx].html(0);
      this.scoreDisplay.points[idx].data('points', points[idx]);
      this.scoreDisplay.ingamePoints[idx].html(points[idx]);
    }
  }

  afterCountdown() {
  }

  end() {
    for (let i = 0; i < this.state.maxerl.length; i++) {
      this.state.maxerl[i].removeCtrlListeners();
      this.state.maxerl[i].controller.emitter.removeAllListeners('disconnect');
    }

    $(`#${this.config.unit} .points`).addClass('visible');
    setTimeout(() => { global.gm.endCurrentGame(); }, 3000);
  }

}

module.exports = BaseGame;
