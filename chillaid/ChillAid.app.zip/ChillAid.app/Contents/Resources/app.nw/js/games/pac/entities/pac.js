const utils = require('../../../modules/utils.js');

function getSprite(game) {
  const sprite = game.add.sprite(1920 / 2, 1080 / 2, 'pac');
  sprite.anchor.setTo(0.5, 0.5);
  sprite.animations.add('waka', [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0], 30, true);
  sprite.animations.add('die', [5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 15, false);
  sprite.animations.add('revive', [5, 6, 7, 8, 9, 10, 11, 12, 13, 14].reverse(), 5, false);
  sprite.animations.play('revive');

  return sprite;
}

function coordsToIdcs(x, y) {
  const conf = this.parent.config;
  x = x - conf.offset;
  y = y - conf.offset;
  x = Math.round(x / conf.pacSize + 0.5) - 1;
  y = Math.round(y / conf.pacSize + 0.5) - 1;
  return {
    x,
    y,
  };
}

class Pac {
  constructor(config) {
    this.parent = config.parent;
    this.reset();

    const img = this.parent.game.add.bitmapData(20, 20);
    img.ctx.beginPath();
    img.ctx.rect(0, 0, 20, 20);
    img.ctx.fillStyle = 'lime';
    img.ctx.fill();

    this.respawnTimeout = false;
    this.chaseInterval = setInterval(() => {
      if (!this.dying && !this.parent.game.paused) {
        this.chaseClosestMax();
      }
    }, 50);
  }

  moveTo(x, y) {
    if (this.countDown >= 0) {
      return;
    }
    const p = this.wayTo(x, y);
    if (typeof(p) === 'undefined') {
      return;
    }
    if (this.nextMoves.length > 0) {
      this.nextMoves = this.nextMoves.splice(0, 1).concat(p);
    } else {
      this.nextMoves = p;
      this.setDirection();
    }
  }

  wayTo(x, y) {
    let pacIdcs;
    if (this.nextMoves.length > 0) {
      pacIdcs = coordsToIdcs.bind(this)(this.nextMoves[0].x, this.nextMoves[0].y);
    } else {
      pacIdcs = coordsToIdcs.bind(this)(this.sprite.x, this.sprite.y);
    }
    const maxIdcs = coordsToIdcs.bind(this)(x, y);

    return this.parent.config.pacSearchObject[
      `${pacIdcs.x}_${pacIdcs.y}|${maxIdcs.x}_${maxIdcs.y}`
    ];
  }

  chaseClosestMax() {
    const maxerl = this.parent.state.maxerl;
    let closestMax = false;
    let closestDistance = Infinity;
    const conf = this.parent.config;
    for (let i = 0; i < maxerl.length; i++) {
      if (maxerl[i].state.is(maxerl[i].state.dead)) {
        continue;
      }
      maxerl[i].chased = false;
      const disX = maxerl[i].sprite.x - this.sprite.x;
      const disY = (maxerl[i].sprite.y - maxerl[i].sprite.body.height / 2) - this.sprite.y;
      const dis = Math.sqrt(disX * disX + disY * disY);
      if (dis - maxerl[i].sprite.body.width / 2 < conf.pacSize / 2) {
        maxerl[i].die();
        maxerl[i].startRevive.bind(maxerl[i])(2);
      } else if (dis < closestDistance) {
        closestDistance = dis;
        closestMax = i;
      }
    }
    if (closestMax !== false) {
      maxerl[closestMax].chased = true;
      const x = maxerl[closestMax].sprite.x;
      const y = maxerl[closestMax].sprite.y - maxerl[closestMax].sprite.body.height / 2;
      const coords = coordsToIdcs.bind(this)(x, y);
      if (typeof this.wayTo(x, y) !== 'undefined') {
        this.sprite.tint = `0x${utils.rgbToHex(maxerl[closestMax].team.color)}`;
      } else {
        this.sprite.tint = '0x00000';
      }

      if (typeof conf.maze[coords.x] !== 'undefined' && conf.maze[coords.x][coords.y]) {
        let closest2Max = false;
        let closest2Distance = Infinity;
        const free = this.freeNeighbours({ x: coords.x, y: coords.y }, []);
        for (let i = 0; i < free.length; i++) {
          const tileX = (free[i].x + 1) * conf.pacSize + conf.offset - conf.pacSize / 2;
          const tileY = (free[i].y + 1) * conf.pacSize + conf.offset - conf.pacSize / 2;
          const disX = x - tileX;
          const disY = y - tileY;
          const dis = Math.sqrt(disX * disX + disY * disY);
          if (dis < closest2Distance) {
            closest2Distance = dis;
            closest2Max = { x: tileX, y: tileY };
          }
        }
        if (closest2Max !== false) {
          this.moveTo(closest2Max.x, closest2Max.y);
        }
      } else {
        this.moveTo(x, y);
      }
    } else {
      this.sprite.tint = '0x00000';
    }
  }

  freeNeighbours(spot, visited) {
    const conf = this.parent.config;
    const ret = [];
    const neighbours = [[-1, 0], [1, 0], [0, -1], [0, 1]];
    for (let i = 0; i < neighbours.length; i++) {
      const theX = spot.x + neighbours[i][0];
      const theY = spot.y + neighbours[i][1];
      if (theX < 0 || theX >= conf.maze.length || theY < 0 || theY >= conf.maze[0].length) {
        continue;
      }
      if (conf.maze[theX][theY] === false) {
        const p = {
          x: theX,
          y: theY,
        };
        if (visited.indexOf(JSON.stringify(p)) === -1) {
          ret.push(p);
        }
      }
    }
    return ret;
  }

  setDirection() {
    this.directionX = 0;
    this.directionY = 0;
    if (this.nextMoves.length === 0) {
      return;
    }
    if (this.nextMoves[0].x < this.sprite.x) {
      this.directionX = this.speed * -1;
      this.sprite.rotation = Math.PI;
    } else if (this.nextMoves[0].x > this.sprite.x) {
      this.directionX = this.speed;
      this.sprite.rotation = 0;
    } else if (this.nextMoves[0].y < this.sprite.y) {
      this.directionY = this.speed * -1;
      this.sprite.rotation = Math.PI * 1.5;
    } else if (this.nextMoves[0].y > this.sprite.y) {
      this.directionY = this.speed;
      this.sprite.rotation = Math.PI * 0.5;
    }
  }

  addRandomMoves() {
    const coords = coordsToIdcs.bind(this)(this.sprite.x, this.sprite.y);
    const conf = this.parent.config;
    const route = [coords];
    const visited = [];
    for (let i = 0; i < 7; i++) {
      const free = this.freeNeighbours(route[route.length - 1], visited);
      if (free.length > 0) {
        const next = free[utils.ranInt(0, free.length - 1)];
        visited.push(JSON.stringify(next));
        route.push(next);
      }
    }
    for (let i = 0; i < route.length; i++) {
      route[i].x = (route[i].x + 1) * conf.pacSize + conf.offset - conf.pacSize / 2;
      route[i].y = (route[i].y + 1) * conf.pacSize + conf.offset - conf.pacSize / 2;
    }
    route.splice(0, 1);
    this.nextMoves = route;
  }

  update() {
    if (this.countDown >= 0) {
      this.countDown -= 1;
      return;
    } else if (this.countDown !== false) {
      this.countDown = false;
      this.sprite.animations.play('waka');
    }
    if (!this.dying && this.nextMoves.length > 0) {
      const pastX = ((this.directionX < 0 && this.sprite.x <= this.nextMoves[0].x) ||
      (this.directionX >= 0 && this.sprite.x >= this.nextMoves[0].x));
      const pastY = ((this.directionY < 0 && this.sprite.y <= this.nextMoves[0].y) ||
      (this.directionY >= 0 && this.sprite.y >= this.nextMoves[0].y));

      if (pastY && pastX) {
        if (this.nextMoves[0].x !== this.sprite.x || this.nextMoves[0].y !== this.sprite.y) {
          this.sprite.x = this.nextMoves[0].x;
          this.sprite.y = this.nextMoves[0].y;
        }
        this.nextMoves.splice(0, 1);
        if (this.nextMoves.length > 0) {
          this.setDirection();
        } else {
          this.addRandomMoves();
          this.setDirection();
        }
      } else {
        this.sprite.x += this.directionX;
        this.sprite.y += this.directionY;
      }
    }
  }

  destroy(gameIsEnding) {
    this.dying = true;
    this.sprite.animations.stop('waka');
    this.sprite.animations.play('die');
    if (!gameIsEnding) {
      this.respawnTimeout = setTimeout(() => {
        this.respawnTimeout = false;
        this.sprite.destroy();
        this.reset();
      }, 500);
    }
  }

  reset() {
    this.sprite = getSprite(this.parent.game, this.parent.config);
    this.nextMoves = [];
    this.speed = 7;
    this.directionX = this.speed;
    this.directionY = 0;
    this.dying = false;
    this.countDown = 110;
    this.respawning = false;
  }

}

module.exports = Pac;
