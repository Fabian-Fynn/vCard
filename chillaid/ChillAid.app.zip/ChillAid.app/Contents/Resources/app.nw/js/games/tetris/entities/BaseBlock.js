class BaseBlock {
  constructor(options) {
    this.parentState = options.parent.state;
    this.game = options.parent.game;
    this.team = options.team;
    this.parent = options.parent;
    this.down = false;
    this.sprites = [];
    this.config = {
      y: -200,
      spriteScale: 0.5,
      startVelocity: options.parent.config.curVelocityBase,
      blockWidth: 0,
    };
    this.boundVectors = {
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
    };

    this.config.blockWidth = 100 * this.config.spriteScale;
  }

  calculateBoundVectors() {
    let bounds = {};
    if (this.sprites.length === 1) {
      bounds = {
        top: this.sprites[0].top,
        bottom: this.sprites[0].bottom,
        left: this.sprites[0].left,
        right: this.sprites[0].right,
        center: {},
      };
    } else {
      bounds = {
        top: this.sprites.reduce((p, c) => { return ((c.top < p.top) ? c.top : p.top) }),
        bottom: this.sprites.reduce((p, c) => { return ((c.bottom > p.bottom) ? c.bottom : p.bottom) }),
        left: this.sprites.reduce((p, c) => { return ((c.left < p.left) ? c.left : p.left) }),
        right: this.sprites.reduce((p, c) => { return ((c.right > p.right) ? c.right : p.right) }),
      };
    }

    this.boundVectors = {
      top: bounds.top - this.sprites[0].y,
      bottom: bounds.bottom - this.sprites[0].y,
      left: bounds.left - this.sprites[0].x,
      right: bounds.right - this.sprites[0].x,
    };
  }

  getBounds() {
    return {
      top: this.sprites[0].y + this.boundVectors.top,
      bottom: this.sprites[0].y + this.boundVectors.bottom,
      left: this.sprites[0].x + this.boundVectors.left,
      right: this.sprites[0].x + this.boundVectors.right,
    };
  }

  keepInAreaBounds() {
    const currentBounds = this.getBounds();
    const left = this.team === 'red' ? 0 : 970;
    const right = this.team === 'red' ? 950 : 1920;

    if (currentBounds.left < left) {
      this.move(Math.abs(currentBounds.left - left));
    } else if (currentBounds.right > right) {
      this.move(-1 * Math.abs(currentBounds.right - right));
    }
    this.removeSlots();
  }

  removeSlots() {
    const currentBounds = this.getBounds();
    const l = currentBounds.left >= 960 ? currentBounds.left - 20 : currentBounds.left;
    const r = currentBounds.left >= 960 ? currentBounds.right - 20 : currentBounds.right;
    const lSlot = l / this.config.blockWidth;
    const rSlot = r / this.config.blockWidth - 1;
    for (let i = lSlot; i <= rSlot; i++) {
      this.parent.removeSlot(this.team, i);
    }
  }

  move(x) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].x += x;
    }
  }

  setSpeed(velocity) {
    this.currentSpeed = velocity;
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].body.velocity.y = (1 + this.speedFactor) * this.currentSpeed;
    }
  }

  setSpeedFactor(f) {
    this.speedFactor = f;
    this.setSpeed(this.currentSpeed);
  }

  createSprite(sprites) {
    for (let i = 0; i < sprites.length; i++) {
      const spriteConfig = sprites[i];
      const x = spriteConfig.vectors[0][0] * this.config.blockWidth + this.config.x;
      const y = spriteConfig.vectors[0][1] * this.config.blockWidth + this.config.y;

      const sprite = this.game.add.sprite(x, y, this.game.cache.getBitmapData(spriteConfig.name));
      sprite.block = this;

      sprite.anchor.setTo(0.5, 0.5);

      sprite.outOfBoundsKill = true;
      sprite.checkWorldBounds = true;
      sprite.scale.x = this.config.spriteScale;
      sprite.scale.y = this.config.spriteScale;

      this.game.physics.arcade.enable(sprite);
      sprite.body.mass = 0;
      sprite.body.immovable = false;
      sprite.body.allowGravity = false;
      sprite.body.collideWorldBounds = false;

      this.sprites.push(sprite);
      this.parentState.blockSprites[this.team].falling.push(sprite);
      this.parentState.lastSpawned[this.team] = sprite;
    }
    this.speedFactor = 1;
    this.setSpeed(this.config.startVelocity);
    this.calculateBoundVectors();

    this.game.world.bringToTop(this.parent.debugLR);
    this.game.world.bringToTop(this.parent.debugLB);
    for (let i = 0; i < this.parentState.maxerl.length; i++) {
      this.game.world.bringToTop(this.parentState.maxerl[i].sprite);
      this.game.world.bringToTop(this.parentState.maxerl[i].name);
    }
  }
}

module.exports = BaseBlock;
