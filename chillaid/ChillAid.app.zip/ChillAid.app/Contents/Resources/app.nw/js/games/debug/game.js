const BaseGame = require('../base/base.js');

const preload = require('./functions/preload.js');
const create = require('./functions/create.js');
const update = require('./functions/update.js');
const render = require('./functions/render.js');
const init = require('./functions/init.js');

class DebugGame extends BaseGame {
  constructor() {
    super();

    this.config = $.extend({
      unit: 'debug-canvas',
      minTeamPlayers: 0,
      roundName: 'Debug',
    }, this.config);

    this.state = $.extend({

    }, this.state);

    this.game = new Phaser.Game(1920, 1080, Phaser.AUTO, this.config.unit, {
      preload: preload.bind(this),
      create: create.bind(this),
      update: update.bind(this),
      render: render.bind(this),
      init: init.bind(this),
    });
  }

  end() {
    for (let i = 0; i < this.state.maxerl.length; i++) {
      this.state.maxerl[i].removeCtrlListeners();
      this.state.maxerl[i].controller.emitter.removeAllListeners('disconnect');
    }
    global.gm.endCurrentGame();
  }
}

module.exports = DebugGame;
