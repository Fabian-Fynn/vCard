
function init() {
  this.baseFunctions.init.bind(this)();
  $(`#${this.config.unit} .tetris-points`).remove();
  $(`#${this.config.unit}`).append([
    '<div class="ingame-points hidden tetris-points">',
    '<span class="red"></span><span class="blue"></span>',
    '</div>',
  ].join(''));
}

module.exports = init;
