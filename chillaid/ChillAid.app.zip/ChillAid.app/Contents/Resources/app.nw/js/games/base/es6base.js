var cs = require('../../modules/frontend/canvas_scaler.js');
var us = require('../../modules/frontend/unit_switcher.js');
var tm = require('../../modules/game_management/team_manager.js');

class BaseGame {
  constructor() {
    this.baseFunctions = {
      create(){
        this.game.add.sprite(0, 0, 'bg');
        this.game.physics.startSystem(Phaser.Physics.ARCADE);
      },
      init(){
        var canvasWrapper = this.config.unit;
        cs.init($('#' + canvasWrapper + ' canvas'));
        us.switchToUnit(canvasWrapper);
      },
      preload(){
        this.game.load.image('bg', 'assets/snake/background.png');
        this.game.load.spritesheet('max', 'assets/snake/max.png', 100, 100);
      },
      render(){
        for(var i = 0; i < this.state.maxerl.length; i++) {
          this.game.debug.body(this.state.maxerl[i].sprite);
        }
      },
      update(){}
    };
    this.config = {

    }
    this.state = {
        game: null,
        maxerl: [],
        countdown: 212,
        controllerStates: null,
        teams: null,
        tickCounter: 0
      }
    this.teams = tm.getTeams();
  }

}

module.exports = BaseGame;