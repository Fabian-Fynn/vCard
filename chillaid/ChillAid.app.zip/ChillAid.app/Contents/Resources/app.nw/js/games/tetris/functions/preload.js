
function preload() {
  this.baseFunctions.preload.bind(this)();

  this.game.load.image('bg', 'assets/snake/background.png');

  this.game.load.image('two-block', 'assets/tetris/tetris-2.png');
  this.game.load.image('two-block-flat', 'assets/tetris/tetris-2-flat.png');
  this.game.load.image('three-block', 'assets/tetris/tetris-3.png');
  this.game.load.image('three-block-flat', 'assets/tetris/tetris-3-flat.png');
  this.game.load.image('four-block', 'assets/tetris/tetris-4.png');
  this.game.load.image('four-block-flat', 'assets/tetris/tetris-4-flat.png');
  this.game.load.image('2x2-block', 'assets/tetris/tetris-2x2.png');

  const img = this.game.add.bitmapData(950, 10);
  img.ctx.fillStyle = 'white';
  img.ctx.fillRect(0, 0, 950, 10);

  this.game.load.image('debugLine', img.canvas.toDataURL());
}

module.exports = preload;
