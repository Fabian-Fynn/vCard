const utils = require('../../../../modules/utils.js');
const BaseBlock = require('../BaseBlock.js');

class LBlock extends BaseBlock {
  constructor(options) {
    super(options);

    const rotationArr = typeof options.fixedRotation === 'object' ? options.fixedRotation : [0,90,-90,180];
    const rotation = rotationArr[utils.ranInt(0, rotationArr.length - 1)];

    const sprites = [
      {
        name: 'three-block_5',
        vectors: [[0, 0]],
      },
      {
        name: 'two-block-flat_5',
        vectors: [[-0.5, 1]],
      },
    ];

    switch (rotation) {
      case 90:
        sprites[0].name = 'three-block-flat_5';
        sprites[1].name = 'two-block_5';
        sprites[1].vectors = [[-1, -0.5]];
        break;
      case -90:
        sprites[0].name = 'three-block-flat_5';
        sprites[1].name = 'two-block_5';
        sprites[1].vectors = [[1, 0.5]];
        break;
      case 180:
        sprites[0].name = 'three-block_5';
        sprites[1].name = 'two-block-flat_5';
        sprites[1].vectors = [[0.5, -1]];
        break;
      default: break;
    }


    const slot = options.slot;

    this.config.x = (slot * this.config.blockWidth) + this.config.blockWidth * 1.5;
    if (slot > 18) {
      this.config.x += 20;
    }
    switch (rotation) {
      case 180:
        this.config.x -= this.config.blockWidth;
        break;
      default: break;
    }

    this.createSprite(sprites);
    this.keepInAreaBounds();
  }
}

module.exports = LBlock;
