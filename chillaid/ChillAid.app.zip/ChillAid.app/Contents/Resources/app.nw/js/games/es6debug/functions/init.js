
function init() {
  this.baseFunctions.init.bind(this)();
}

module.exports = init;