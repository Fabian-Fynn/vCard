function create() {
  this.baseFunctions.create.bind(this)({
    red: [{ x: 530, y: 380 }, { x: 425, y: 380 }, { x: 320, y: 380 }, { x: 215, y: 380 }],
    blue: [{ x: 1395, y: 380 }, { x: 1495, y: 380 }, { x: 1600, y: 380 }, { x: 1705, y: 380 }],
  });
}

module.exports = create;
