const utils = require('../../../modules/utils.js');

class TetrisBlock {
  constructor(config, position) {
    //this.type = config.type;
    this.config = {
      game: config.parent.game,
      state: config.parent.state,
      types: [
        { name: 'O' },
        { name: 'L' },
        { name: 'LL' },
        { name: 'T' },
        { name: 'Z' },
        { name: 'ZZ' }
      ],
      spriteScale: 0.5
    }

    const blockWidth = 100 * this.config.spriteScale;
    const xSlots = 1800 / blockWidth;
    this.config.x = position? position : utils.ranInt(0, xSlots) * blockWidth + 35;
    this.config.blockType = this.config.types[ utils.ranInt(0, this.config.types.length - 1) ];

    this.sprites = [];

    window.blocks = this.sprites;
    this.createSprite();
    //console.log(this);
  };

  createSprite() {
    const spriteA = this.config.game.add.sprite(this.config.x, 0, 'two-block');

    spriteA.scale.x = this.config.spriteScale;
    spriteA.scale.y = this.config.spriteScale;

    this.config.game.physics.arcade.enable(spriteA);
    spriteA.anchor.setTo(0.5, 1);

    spriteA.body.collideWorldBounds = true;
    spriteA.body.gravity.y = 1600;
    spriteA.body.immovable = false;
    this.sprites.push( spriteA );
    this.config.state.blockGroup.add(spriteA);
  }

  drop() {
    for( let i = 0; i < this.sprites.length; i++ ) {
      //this.sprites[i].y += 50;
    }
  }
}

module.exports = TetrisBlock;
