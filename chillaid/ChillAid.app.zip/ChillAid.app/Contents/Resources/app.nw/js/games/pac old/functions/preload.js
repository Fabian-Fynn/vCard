var APP = window.APP || {};
APP.Games = APP.Games || {};
APP.Games.Pac = APP.Games.Pac || {};
APP.Games.Pac.functions = APP.Games.Pac.functions || {};

APP.Games.Pac.functions.preload = (function(){

  function preload() {
    APP.BaseGame.preload();

    APP.currentlyRunningGame.load.spritesheet('pac', createPacSprite(), APP.Games.Pac.config.pacSize, APP.Games.Pac.config.pacSize);
  }

  function createPacSprite() {
    var frames = 5;
    var deathFrames = 10;
    var img = APP.currentlyRunningGame.add.bitmapData(APP.Games.Pac.config.pacSize*(frames + deathFrames), APP.Games.Pac.config.pacSize);

    for(var i = 0; i < frames; i++) {
      drawIteration(img,i,0.25*(i/frames));
    }
    for(i = frames; i < frames + deathFrames; i++) {
      drawIteration(img,i,0.6*(i/deathFrames));
    }

    function drawIteration(img, idx, opening) {
      var cx = APP.Games.Pac.config.pacSize/2 + APP.Games.Pac.config.pacSize*idx;
      var cy = APP.Games.Pac.config.pacSize/2;
      var curveStart = APP.Utils.rotateVec(cx,cy,cx+APP.Games.Pac.config.pacSize/2,cy,opening*Math.PI);
      img.ctx.beginPath();
      img.ctx.moveTo(curveStart[0],curveStart[1]);
      img.ctx.lineTo(cx,cy);
      img.ctx.lineTo(curveStart[0],APP.Games.Pac.config.pacSize - curveStart[1]);
      img.ctx.arc(cx,cy,APP.Games.Pac.config.pacSize/2,opening*Math.PI,(2-opening)*Math.PI); //x, y, radius, startAng, endAng
      img.ctx.fillStyle = 'black';
      img.ctx.fill();
    }
    console.log(img.canvas.toDataURL())
    return img.canvas.toDataURL();
  }

  return preload;
})();