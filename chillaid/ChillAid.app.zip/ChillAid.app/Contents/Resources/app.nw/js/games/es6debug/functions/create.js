var Max = require('../../base/entities/max.js');

function create() {
  this.baseFunctions.create.bind(this)();
  var nameStyle = { font: "normal 22px Lato", fill: "#000", boundsAlignH: "center", boundsAlignV: "middle" };
  for(var idx in this.teams) {
    for(var y = 0; y < this.teams[idx].members.length; y++) {
      var maxX = 500;
      var maxY = 500;

      var maxConfig = {
        x: maxX,
        y: maxY,
        diretion: 1,
        controller: global.controllerManager.get(this.teams[idx].members[y]),
        team: idx,
        name: this.game.add.text(maxX, maxY, 'APP.ControllerStates.controllerState(this.teams[idx].members[y]).name', nameStyle),
        parent: this
      };

      this.state.maxerl.push(new Max(maxConfig));
    }
  }
}

module.exports = create;