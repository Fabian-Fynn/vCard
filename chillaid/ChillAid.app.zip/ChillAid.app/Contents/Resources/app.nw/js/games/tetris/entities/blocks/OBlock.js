const utils = require('../../../../modules/utils.js');
const BaseBlock = require('../BaseBlock.js');

class IBlock extends BaseBlock {
  constructor(options) {
    super(options);

    const sprites = [{
      name: '2x2-block_0',
      vectors: [[0, 0, 0]],
    }];

    const slot = options.slot;

    this.config.x = slot * this.config.blockWidth + this.config.blockWidth;
    if (slot > 18) {
      this.config.x += 20;
    }

    this.createSprite(sprites);
    this.keepInAreaBounds();
  }
}

module.exports = IBlock;
