
function render() {
  this.baseFunctions.render.bind(this)();
}

module.exports = render;