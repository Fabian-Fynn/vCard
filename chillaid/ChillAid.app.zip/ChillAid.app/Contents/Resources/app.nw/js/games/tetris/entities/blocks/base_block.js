const utils = require('../../../../modules/utils.js');

class TetrisBlock {
  constructor(options) {
    this.parentState = options.parent.state;
    this.game = options.parent.game;
    this.team = options.team;
    this.down = false;
    this.sprites = [];
    this.rotations = 0;
    this.createConfig();

    if(this.parentState.slots[this.team].length === 0){
      this.parentState.slots[this.team] = $.extend([], this.config.slots[this.team]);
    }

    // Do in subtype constructor
    this.createSprite();
    this.rotate(utils.ranInt(0, 3));
  }

  createConfig() {
    this.config = {
      y: -200,
      spriteScale: 0.5,
      slots: [[], []],
      startVelocity: 400,
      blockWidth: 0,
    };

    this.config.blockWidth = 100 * this.config.spriteScale;
    const xSlots = 1500 / this.config.blockWidth;
    const slots = Array.apply(null, { length: xSlots }).map(Number.call, Number);

    this.config.slots.red = slots.splice(0, xSlots / 2);
    this.config.slots.blue = slots;
  }

  getBounds() {
    return {
      top: this.sprites.reduce((prev, cur) => { return cur.top < prev.top }),
      bottom: this.sprites.reduce((prev, cur) => { return cur.bottom > prev.bottom }),
      left: this.sprites.reduce((prev, cur) => { return cur.left < prev.left }),
      right: this.sprites.reduce((prev, cur) => { return cur.right > prev.right }),
    };
  }

  keepInAreaBounds() {
    const currentBounds = this.getBounds();

    if (currentBounds.left < 0) {
      this.move(-1 * currentBounds.left);
    } else if (currentBounds.right > 1920) {
      this.move(-1 * currentBounds.left);
    }
  }

  move(x) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].x += x;
    }
  }

  rotate(deg) {
    const bounds = this.getBounds();
    const x = bounds.right - bounds.left;
    const y = bounds.top - bounds.bottom;

    for (let i = 0; i < this.sprites.length; i++) {
      const s = this.sprites[i];
      const rotated = utils.rotateVec(x, y, s.x, s.y, deg * (Math.PI / 180));
      s.x = rotated.x;
      s.y = rotated.y;
      s.angle = deg;
    }
  }

  hitGround() {
    for (let i = 0; i < this.sprites.length; i++) {
      // TODO: Add correct sink velocity
      this.sprites[i].body.velocity.y = 10;//this.parentState.currentSinkVelocity;
    }
  }

  slow(velocity) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].body.velocity.y = velocity;
    }
  }
}

module.exports = TetrisBlock;
