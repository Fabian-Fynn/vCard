const utils = require('../../../modules/utils.js');

class MaxActions {
  constructor() {
    this.speed = 550;
    this.jumpStrenght = -900;
  }

  stand() {
    if (this.state.change(this.state.stand) || this.state.is(this.state.stand)) {
      this.stopAnimations();
      const frame = this.crouching ? 13 : 0;
      const height = this.crouching ? 45 : 93;
      this.sprite.frame = frame;
      this.sprite.body.setSize(30, height, 0, -4);
      this.sprite.body.velocity.x = 0;
    }
  }

  run(data) { // Triggered through controller
    this.sprite.body.direction = data.translatedDir.right ? 1 : 0;
    const height = this.crouching ? 45 : 93;
    this.sprite.body.setSize(30, height, 0, -4);

    if (this.state.change(this.state.run)) {
      const animation = this.crouching ? 'crouchMove' : 'walk';
      const animationSpeed = 230 - 150 * (data.intensity / (this.crouching ? 2 : 1) / 100);
      this.sprite.animations.getAnimation(animation).delay = animationSpeed;
      this.sprite.animations.play(animation);

      const directionMultiplier = this.sprite.body.direction === 0 ? -1 : 1;
      this.sprite.scale.x = directionMultiplier;

      const vx = this.speed * (data.intensity / (this.crouching ? 2 : 1)) / 100;
      this.sprite.body.velocity.x = directionMultiplier * vx;
    }
  }

  land() {
    if (this.state.change(this.state.land)) {
      this.stopAnimations();
      const dir = this.controller.state.keyStates.dir;
      if (!dir) {
        this.stand();
      } else {
        this.run(dir);
      }
    }
  }

  jump() {
    if (this.crouching) {
      return;
    }

    if (this.state.is(this.state.slide)) {
      const directionMultiplier = this.sprite.body.direction === 0 ? 1 : -1;
      this.removeCtrlListeners();
      this.sprite.scale.x = directionMultiplier;
      this.sprite.body.velocity.x = -1 * directionMultiplier * this.jumpStrenght / 2;
      setTimeout(this.regainControl.bind(this), 300);
    }

    if (this.state.change(this.state.jump)) {
      this.sprite.body.velocity.y = this.jumpStrenght;
      this.stopAnimations();
      this.sprite.animations.play('jump');
    }
  }


  slideCollide(max, collisionSprite) {
    if (collisionSprite.height < max.height) {
      return;
    }
    this.collisionSprite = collisionSprite;
    if (this.state.change(this.state.slide)) {
      this.stopAnimations();
      this.sprite.animations.play('slide');
      // this.checkSlide();
    }
  }

  slide() {
    if (this.state.change(this.state.slide)) {
      this.state.current.x = this.sprite.x;
      this.stopAnimations();
      this.sprite.animations.play('slide');
    }
  }

  fall() {
    if (this.state.change(this.state.fall)) {
      this.stopAnimations();
      this.sprite.animations.play('fall');
    }
  }

  die() {
    if (this.state.change(this.state.dead)) {
      this.sprite.body.velocity.x = 0;
      this.sprite.body.velocity.y = 0;
      this.stopAnimations();
      this.sprite.animations.play('die');
      this.removeCtrlListeners();
      this.controller.sendData('vibrate', 750);
    }
  }

  shove() {
    if (this.state.change(this.state.shove)) {
      this.removeCtrlListeners();
      this.sprite.body.velocity.x = 0;
      this.stopAnimations();
      this.sprite.animations.play('shove');

      const state = this.parent.state;
      for (let i = 0; i < state.maxerl.length; i++) {
        if ((this.sprite.body.direction === 1 && state.maxerl[i].sprite.x < this.sprite.x) ||
          (this.sprite.body.direction === 0 && state.maxerl[i].sprite.x > this.sprite.x) ||
          (this.sprite.key === state.maxerl[i].sprite.key)) {
          continue;
        }
        const dis = utils.dist(
          this.sprite.x,
          this.sprite.y,
          state.maxerl[i].sprite.x,
          state.maxerl[i].sprite.y
        );

        if (dis < 100) {
          state.maxerl[i].getShoved({ intensity: (100 - dis), dir: this.sprite.body.direction });
        }
      }

      this.timeouts.shove = setTimeout(() => {
        delete this.timeouts.shove;
        this.regainControl();
      }, 500);
    }
  }

  regainControl() {
    if (this.reviveSprite !== null) {
      return;
    }
    this.addCtrlListeners();
    const ks = this.controller.state.keyStates;
    this.crouching = ks.down;
    this.stand();
    if (ks.dir) {
      this.run(ks.dir);
    }
  }

  getShoved(data) {
    const shoveStrenghtX = (this.crouching ? 350 : 700) / 50 * data.intensity;
    const shoveStrenghtY = 200 + data.intensity;
    this.sprite.body.velocity.y -= shoveStrenghtY;
    this.sprite.body.velocity.x += shoveStrenghtX * (data.dir === 1 ? 1 : -1);
  }
}

module.exports = MaxActions;
