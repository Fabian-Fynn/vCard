var APP = window.APP || {};
APP.Games = APP.Games || {};
APP.Games.Pac = APP.Games.Pac || {};
APP.Games.Pac.functions = APP.Games.Pac.functions || {};

APP.Games.Pac.functions.create = (function(){

  function create() {
    APP.BaseGame.create();
    var game = APP.GameManager().currentGame;
    var state = game.gameState;

    state.mazeGroup = APP.currentlyRunningGame.add.physicsGroup();
    state.mazeGroup.enableBody = true;
    state.mazeGroup.physicsBodyType = Phaser.Physics.ARCADE;

    state.endzones = {
      red: new game.GameEntities.Endzone({
        x: 0,
        y: 273,
        w: 247,
        h: 534,
        c: 'rgba(0,0,255,0.3)'
      }),
      blue: new game.GameEntities.Endzone({
        x: 1920 - 247,
        y: 273,
        w: 247,
        h: 534,
        c: 'rgba(255,0,0,0.3)'
      })
    }
    addMazeNew();
    addMaxerl(state);
    state.pac = new game.GameEntities.Pac();
  }

  function addMaxerl(state) {
    var nameStyle = { font: "normal 22px Lato", fill: "#000", boundsAlignH: "center", boundsAlignV: "middle" };
    for(var idx in state.teams) {
      for(var y = 0; y < state.teams[idx].length; y++) {

        var maxX = 700;
        var maxY = 500;

        var maxConfig = {
          collideEverywhere: true,
          x: maxX,
          y: maxY,
          diretion: 1,
          controllerSlot: state.teams[idx][y],
          team: idx,
          name: APP.currentlyRunningGame.add.text(maxX, maxY, APP.ControllerStates.controllerState(state.teams[idx][y]).name, nameStyle)
        };
        var max = new APP.Max(maxConfig);
        max.sprite.scale.set(0.8);
        state.maxerl.push(max);
      }
    }
  }

  function addMazeNew() {
    var game = APP.GameManager().currentGame;
    var conf = game.config;
    var state = game.gameState;

    for(var i = 0; i < conf.mazeSprites.length; i++) {
      var s = conf.mazeSprites[i];
      var img = APP.currentlyRunningGame.add.bitmapData(s.w, s.h);
      img.ctx.beginPath();
      img.ctx.rect(0, 0, s.w, s.h);
      img.ctx.fillStyle = 'black';
      img.ctx.fill();

      var sprite = state.mazeGroup.create(s.x, s.y, img);
      sprite.body.immovable = true;
      sprite.body.checkCollision.down = false;
    }
  }

  return create;
})();