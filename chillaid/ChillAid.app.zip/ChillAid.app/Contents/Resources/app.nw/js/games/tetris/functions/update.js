function collide(a, b) {
  if (a.block === b.block) {
    return;
  }

  for (let y = 0; y < a.block.sprites.length; y++) {
    const s = a.block.sprites[y];
    const spriteIdx = a.block.parentState.blockSprites[a.block.team].falling.indexOf(s);
    a.block.parentState.blockSprites[a.block.team].falling.splice(spriteIdx, 1);
    a.block.parentState.blockSprites[a.block.team].sinking.push(s);
  }
  a.block.setSpeed(a.block.parentState.sinkVelocity);
  b.block.setSpeed(b.block.parentState.sinkVelocity);
}

function collideMax(block, maxSprite) {
  maxSprite.max.land();
  block.block.setSpeed(block.block.currentSpeed);
  maxSprite.body.velocity.y = block.body.velocity.y;
}

function updateMaxerl() {
  const height = { red: 0, blue: 0 };
  const amount = { red: 0, blue: 0 };

  for (let i = 0; i < this.state.maxerl.length; i++) {
    const m = this.state.maxerl[i];
    if (m.state.current !== m.state.dead) {
      this.game.physics.arcade.collide(this.state.blockSprites.red.falling, m.sprite, collideMax);
      this.game.physics.arcade.collide(this.state.blockSprites.red.sinking, m.sprite, collideMax);
      this.game.physics.arcade.collide(this.state.blockSprites.blue.falling, m.sprite, collideMax);
      this.game.physics.arcade.collide(this.state.blockSprites.blue.sinking, m.sprite, collideMax);
      m.update();
    }
    amount[m.team.key]++;
    const currentMaxHeight = this.game.height - m.sprite.y;
    height[m.team.key] += currentMaxHeight;
  }

  height.red = height.red / amount.red;
  height.blue = height.blue / amount.blue;
}

function setSpeedBasedOfPoints(points) {
  for (let idx in this.state.blocks) {
    for (let i = 0; i < this.state.blocks[idx].length; i++) {
      const perc = this.state.blocks[idx][i].team === 'red' ? points.red.perc : points.blue.perc;
      this.state.blocks[idx][i].setSpeedFactor(2 * (1 - perc));
    }
  }
}

function calculatePointsBase() {
  const height = { red: 0, blue: 0 };
  const amount = { red: 0, blue: 0 };
  this.state.maxerl.reduce((prev, cur) => {
    if (cur.team.key === 'red') {
      amount[cur.team.key]++;
      height[cur.team.key] += (cur.sprite.x < 960 ? cur.sprite.body.center.y : 1080);
    } else if (cur.team.key === 'blue') {
      amount[cur.team.key]++;
      height[cur.team.key] += (cur.sprite.x > 960 ? cur.sprite.body.center.y : 1080);
    }
    return 0;
  }, 0);
  const avgR = amount.red === 0 ? 1080 : height.red / amount.red;
  const avgB = amount.blue === 0 ? 1080 : height.blue / amount.blue;

  const percR = avgR / 1080;
  const percB = avgB / 1080;

  this.debugLB.y = avgB;
  this.debugLR.y = avgR;
  return {
    red: {
      avgY: avgR,
      perc: percR,
    },
    blue: {
      avgY: avgB,
      perc: percB,
    },
  };
}

function updateTickBased() {
  this.state.tickCounter++;
  this.state.spawnCountdownPause--;
  const pointsBase = calculatePointsBase.bind(this)();

  if (this.state.lastSpawned.red !== null && this.state.lastSpawned.red.top > -150) {
    this.spawnNewBlock('red');
    this.spawnNewBlock('red');
  }
  if (this.state.lastSpawned.blue !== null && this.state.lastSpawned.blue.top > -150) {
    this.spawnNewBlock('blue');
    this.spawnNewBlock('blue');
  }

  if (!this.ended && this.state.tickCounter % this.config.pointsTick === 0) {
    const curPoints = global.gm.pointManager.getRoundPoints(this.config.roundName);
    if (pointsBase.red.perc < 0.75) {
      global.gm.pointManager.setPoints({
        team: 'red',
        round: this.config.roundName,
        points: curPoints.red + 10 - Math.round(pointsBase.red.perc * 10),
      });
    }
    if (pointsBase.blue.perc < 0.75) {
      global.gm.pointManager.setPoints({
        team: 'blue',
        round: this.config.roundName,
        points: curPoints.blue + 10 - Math.round(pointsBase.blue.perc * 10),
      });
    }
    const newPoints = global.gm.pointManager.getRoundPoints(this.config.roundName);
    if (newPoints.red > 1000 || newPoints.blue > 1000) {
      this.ended = true;
      this.end();
    }
    setSpeedBasedOfPoints.bind(this)(pointsBase);
    this.updateScoreDisplay();
  }
}

function update() {
  this.baseFunctions.update.bind(this)();
  updateMaxerl.bind(this)();
  if (this.config.curVelocityBase > this.config.velocityBase) {
    this.config.curVelocityBase--;
    for (let idx in this.state.blocks) {
      for (let i = 0; i < this.state.blocks[idx].length; i++) {
        this.state.blocks[idx][i].setSpeed(this.config.curVelocityBase);
      }
    }
  }
  for (let idx in this.state.blocks) {
    for (let i = 0; i < this.state.blocks[idx].length; i++) {
      if (!this.state.blocks[idx][i].sprites[0].exists) {
        for (let y = 0; y < this.state.blocks[idx][i].sprites.length; y++) {
          const s = this.state.blocks[idx][i].sprites[y];
          const spriteIdx = this.state.blockSprites[idx].sinking.indexOf(s);
          this.state.blockSprites[idx].sinking.splice(spriteIdx, 1);
        }
        this.state.blocks[idx].splice(i, 1);
      } else if (this.state.blocks[idx][i].getBounds().bottom >= 950 && !this.state.blocks[idx][i].down) {
        for (let y = 0; y < this.state.blocks[idx][i].sprites.length; y++) {
          const s = this.state.blocks[idx][i].sprites[y];
          const spriteIdx = this.state.blockSprites[idx].falling.indexOf(s);
          if (spriteIdx !== -1) {
            this.state.blockSprites[idx].falling.splice(spriteIdx, 1);
            this.state.blockSprites[idx].sinking.push(s);
          }
        }
        this.state.blocks[idx][i].down = true;
        this.state.blocks[idx][i].setSpeed(this.state.sinkVelocity);
      }
    }
  }
  updateTickBased.bind(this)();
  this.game.physics.arcade.collide(
    this.state.blockSprites.red.falling,
    this.state.blockSprites.red.sinking,
    collide
  );
  this.game.physics.arcade.collide(
    this.state.blockSprites.blue.falling,
    this.state.blockSprites.blue.sinking,
    collide
  );
}

module.exports = update;
