const utils = require('../../../modules/utils.js');

class TetrisBlock {
  constructor(options, position) {
    this.config = require('./block_config.js');
    this.state = options.parent.state;
    this.game = options.parent.game;
    this.team = options.team;

    if (!this.state.slots) {
      this.state.slots = [[], []];
    }

    if(this.state.slots[this.team].length === 0){
      this.state.slots[this.team] = $.extend([], this.config.slots[this.team]);
    }

    const index = utils.ranInt(0, this.state.slots[ this.team ].length - 1);
    const slot = this.state.slots[ this.team ][index];

    utils.remove.call(this.state.slots[ this.team ], slot);
    utils.remove.call(this.state.slots[ this.team ], slot - 1);
    utils.remove.call(this.state.slots[ this.team ], slot - 2);
    utils.remove.call(this.state.slots[ this.team ], slot + 1);
    utils.remove.call(this.state.slots[ this.team ], slot + 2);

    this.config.x = position? position : slot * this.config.blockWidth + 200;

    if (this.config.fixedType) {
      this.config.blockType = this.config.types[ this.config.fixedType ];
    } else {
      this.config.blockType = this.config.types[ utils.ranInt(0, this.config.types.length - 1) ];
    }

    this.down = false;
    this.sprites = [];
    this.rotations = 0;

    this.createSprite();
    this.rotate( utils.ranInt(0, 3) );

    const that = this;
    setTimeout( function(){
      that.keepInBounds();
    }, 30);
  };

  keepInBounds() {
    let left = 1920;
    let right = 0;
    for (let i = 0; i < this.sprites.length; i++) {
      if (this.sprites[i].body.x < left) {
        left = this.sprites[i].body.x;
      }
      if (this.sprites[i].body.x + this.sprites[i].body.width > right) {
        right = this.sprites[i].body.x + this.sprites[i].body.width;
      }
    }

    if (left < 0) {
      this.move(-left);
    } else if (left < 950 && this.team === 1) {
      this.move( 950 - left );
    } else if (right > 950 && this.team === 0) {
      this.move( right - 950 );
    } else if (right > 1920) {
      this.move(right - 1920);
    }
  };

  move(x) {
    for (let i = 0; i < this.sprites.length; i++) {
      this.sprites[i].x += x;
    }
  }

  createSprite() {

    for (let i = 0; i < this.config.blockType.sprites.length; i++) {
      const spriteConfig = this.config.blockType.sprites[i];
      const x = spriteConfig.vectors[0][0] * this.config.blockWidth + this.config.x;
      const y = spriteConfig.vectors[0][1] * this.config.blockWidth + this.config.y;

      const img = this.game.make.bitmapData();
      img.load(spriteConfig.name);

      img.shiftHSL(this.config.blockType.HSL);

      const sprite = this.game.add.sprite(x, y, img);
      sprite.block = this;

      this.game.physics.arcade.enable(sprite);
      this.state.blockGroup.add(sprite);

      sprite.body.syncBounds = true;
      sprite.scale.x = this.config.spriteScale;
      sprite.scale.y = this.config.spriteScale;

      sprite.anchor.setTo(0, 0);

      sprite.body.offset.setTo(spriteConfig.offsetVectors[0][0] * this.config.blockWidth, spriteConfig.offsetVectors[0][1] * this.config.blockWidth);

      sprite.angle = 90 * spriteConfig.vectors[0][2];
      sprite.body.collideWorldBounds = true;
      this.game.physics.arcade.checkCollision.up = false;
      sprite.body.velocity.y = 300;
      sprite.body.mass = 0;
      sprite.body.immovable = false;

      this.sprites.push( sprite );
    }
  }

  rotate(turn){
    if (turn === this.rotations || turn < 0 || turn > 3) {
      return;
    }

    for (let i = 0; i < this.sprites.length; i++) {
      const sprite = this.sprites[i];
      const blockWidth = this.config.blockWidth;
      const type = this.config.blockType.sprites[i];
      const vectors = type.vectors;
      const offsetVectors = type.offsetVectors;

      sprite.angle = 90 * vectors[turn][2];
      sprite.x = type.vectors[turn][0] * blockWidth + this.config.x;
      sprite.y = type.vectors[turn][1] * blockWidth + this.config.y;

      sprite.body.offset.x = offsetVectors[turn][0] * blockWidth;
      sprite.body.offset.y = offsetVectors[turn][1] * blockWidth;
    }
    this.rotations = turn;
  }
}

module.exports = TetrisBlock;
