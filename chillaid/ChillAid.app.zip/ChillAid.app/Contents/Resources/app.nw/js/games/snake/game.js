const pd = require('../../modules/game_management/points_display.js');
const BaseGame = require('../base/base.js');
const utils = require('../../modules/utils.js');

const preload = require('./functions/preload.js');
const create = require('./functions/create.js');
const update = require('./functions/update.js');
const render = require('./functions/render.js');
const init = require('./functions/init.js');

class SnakeGame extends BaseGame {
  constructor() {
    super();

    this.config = $.extend({
      unit: 'snake-canvas', // Unit to which the Unit Switcher Module
      snakes: [
        {
          color: 0xff4444,
          length: 12,
          spriteScale: 0.3,
          direction: 1,
          x: 500,
          y: 590,
          parent: this,
        }, {
          color: 0x5555ff,
          length: 12,
          spriteScale: 0.3,
          direction: 3,
          x: 1400,
          y: 590,
          parent: this,
        }],
      randomSnakes: [{
        color: 0xAA3939,
        length: 20,
        spriteScale: 0.3,
        direction: 1,
        x: 800,
        y: 590,
        parent: this,
        controller: 'random',
      }, {
        color: 0x226666,
        length: 20,
        spriteScale: 0.3,
        direction: 1,
        x: 600,
        y: 390,
        parent: this,
        controller: 'random',
      }, {
        color: 0x7A9F35,
        length: 20,
        spriteScale: 0.3,
        direction: 1,
        x: 600,
        y: 790,
        parent: this,
        controller: 'random',
      }, {
        color: 0x7C9B2A,
        length: 20,
        spriteScale: 0.3,
        direction: 3,
        x: 1120,
        y: 590,
        parent: this,
        controller: 'random',
      }, {
        color: 0x1E6F50,
        length: 20,
        spriteScale: 0.3,
        direction: 3,
        x: 1320,
        y: 390,
        parent: this,
        controller: 'random',
      }, {
        color: 0xA5922C,
        length: 20,
        spriteScale: 0.3,
        direction: 3,
        x: 1320,
        y: 790,
        parent: this,
        controller: 'random',
      }],
      spriteScale: 0.3,
      turnTick: 18,
      minTeamPlayers: 1,
      roundName: 'Snake',
    }, this.config);

    this.state = $.extend({
      game: null,
      food: null,
      ranInit: false,
      snakes: [],
      snakeGroup: null,
      maxerl: [],
      controllerStates: null,
      teams: null,
      winner: false,
      tickCounter: 0,
      endzones: {},
    }, this.state);

    this.game = new Phaser.Game(1920, 1080, Phaser.AUTO, this.config.unit, {
      preload: preload.bind(this),
      create: create.bind(this),
      update: update.bind(this),
      render: render.bind(this),
      init: init.bind(this),
    });
  }

  checkWin() {
    if (this.state.winner !== false) {
      return;
    }

    const maxerl = this.state.maxerl;
    const livingRed = maxerl.reduce((prev, cur) => {
      return prev + ((!cur.state.is(cur.state.dead) && cur.team.key === 'red') ? 1 : 0);
    }, 0);
    const livingBlue = maxerl.reduce((prev, cur) => {
      return prev + ((!cur.state.is(cur.state.dead) && cur.team.key === 'blue') ? 1 : 0);
    }, 0);

    global.gm.pointManager.setPoints({ round: 'Snake', team: 'red', points: livingRed });
    global.gm.pointManager.setPoints({ round: 'Snake', team: 'blue', points: livingBlue });

    if (livingRed === 0 && livingBlue === 0) {
      this.state.winner = 'wtf';
      this.end();
    } else if (livingBlue === 0) {
      global.gm.pointManager.addPoint({ game: true, team: 'red' });
      this.state.winner = 'red';
      this.end();
    } else if (livingRed === 0) {
      global.gm.pointManager.addPoint({ game: true, team: 'blue' });
      this.state.winner = 'blue';
      this.end();
    }

    this.updateScoreDisplay();
  }

  repositionFood() {
    this.state.food.x = Math.floor(utils.ranInt(100, 1820) / 30) * 30;
    this.state.food.y = Math.floor(utils.ranInt(100, 980) / 30) * 30;
  }

  end() {
    for (let i = 0; i < this.state.snakes.length; i++) {
      this.state.snakes[i].removeInterval();
    }
    setTimeout(() => {
      pd.displayRoundPoints('snake-canvas');
    }, 1000);

    super.end();
  }
}

module.exports = SnakeGame;
