const Pac = require('../entities/pac.js');
const EndZone = require('../entities/endzone.js');

function addMazeNew() {
  const conf = this.config;
  const state = this.state;

  for (let i = 0; i < conf.mazeSprites.length; i++) {
    const s = conf.mazeSprites[i];
    const img = this.game.add.bitmapData(s.w, s.h);
    img.ctx.beginPath();
    img.ctx.rect(0, 0, s.w, s.h);
    img.ctx.fillStyle = 'black';
    img.ctx.fill();

    const sprite = state.mazeGroup.create(s.x, s.y, img);
    sprite.body.immovable = true;
    sprite.body.checkCollision.down = false;
  }
}

function create() {
  this.baseFunctions.create.bind(this)({
    red: [{ x: 710, y: 555 }, { x: 785, y: 415 }, { x: 785, y: 695 }, { x: 850, y: 555 }],
    blue: [{ x: 1210, y: 555 }, { x: 1135, y: 415 }, { x: 1135, y: 695 }, { x: 1070, y: 555 }],
  });
  const game = this.game;
  const state = this.state;

  state.mazeGroup = game.add.physicsGroup();
  state.mazeGroup.enableBody = true;
  state.mazeGroup.physicsBodyType = Phaser.Physics.ARCADE;

  state.endzones = {
    red: new EndZone({
      x: 0,
      y: 273,
      w: 247,
      h: 534,
      t: 'red',
      c: 'rgba(255,0,0,0.3)',
      parent: this,
    }),
    blue: new EndZone({
      x: 1920 - 247,
      y: 273,
      w: 247,
      h: 534,
      t: 'blue',
      c: 'rgba(0,0,255,0.3)',
      parent: this,
    }),
  };
  addMazeNew.bind(this)();
  state.pac = new Pac({ parent: this });
}

module.exports = create;
