const BaseBlock = require('../BaseBlock.js');

class ZBlock extends BaseBlock {
  constructor(options) {
    super(options);

    const rotation = 90;

    const sprites = [
      {
        name: 'two-block-flat_8',
        vectors: [[0, 0]],
      },
      {
        name: 'two-block-flat_8',
        vectors: [[1, 1]],
      },
    ];

    if (rotation === 90) {
      sprites[0].name = 'two-block_8';
      sprites[1].name = 'two-block_8';
      sprites[1].vectors = [[1, -1]];
    }

    const slot = options.slot;

    this.config.x = (slot * this.config.blockWidth);
    if (slot > 18) {
      this.config.x += 20;
    }
    if (rotation === 90) {
      this.config.x += this.config.blockWidth / 2;
    }

    this.createSprite(sprites);
    this.keepInAreaBounds();
  }
}

module.exports = ZBlock;
