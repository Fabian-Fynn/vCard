const IBlock = require('./blocks/IBlock.js');
const LBlock = require('./blocks/LBlock.js');
const RLBlock = require('./blocks/RLBlock.js');
const TBlock = require('./blocks/TBlock.js');
const OBlock = require('./blocks/OBlock.js');
const ZBlock = require('./blocks/ZBlock.js');
const RZBlock = require('./blocks/RZBlock.js');

module.exports = [
  [
    { Block: IBlock, fixRotation: [0] },
  ],
  [
    { Block: ZBlock },
    { Block: RZBlock },
    { Block: LBlock, fixRotation: [0, 180] },
    { Block: RLBlock, fixRotation: [0, 180] },
    { Block: TBlock, fixRotation: [90, -90] },
    { Block: OBlock },
  ],
  [
    { Block: ZBlock },
    { Block: RZBlock },
    { Block: LBlock },
    { Block: RLBlock },
    { Block: OBlock },
    { Block: TBlock },
  ],
  [
    { Block: IBlock, fixRotation: [90] },
    { Block: ZBlock },
    { Block: RZBlock },
    { Block: LBlock },
    { Block: RLBlock },
    { Block: OBlock },
    { Block: TBlock },
  ],
];
