
function updateMaxerl() {
  for (let i = 0; i < this.state.maxerl.length; i++) {
    if (this.state.maxerl[i].state.current.name !== this.state.maxerl[i].state.dead.name) {
      this.state.maxerl[i].update();
    }
  }
}

function update() {
  this.baseFunctions.update.bind(this)();

  updateMaxerl.bind(this)();
}


module.exports = update;
