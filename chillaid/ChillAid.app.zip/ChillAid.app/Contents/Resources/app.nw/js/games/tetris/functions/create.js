function create() {
  this.state.blocksGroup = this.game.add.group();
  this.baseFunctions.create.bind(this)({
    red: [{ x: 230, y: 1080 }, { x: 425, y: 1080 }, { x: 320, y: 1080 }, { x: 215, y: 1080 }],
    blue: [{ x: 1395, y: 1080 }, { x: 1495, y: 1080 }, { x: 1600, y: 1080 }, { x: 1705, y: 1080 }],
  });

  for (let i = 0; i < this.state.maxerl.length; i++) {
    const max = this.state.maxerl[i];
    max.sprite.body.checkCollision.left = false;
    max.sprite.body.checkCollision.right = false;
    max.sprite.body.checkCollision.up = false;
    max.sprite.body.mass = 0;
  }

  const images = [
    'two-block',
    'two-block-flat',
    'three-block',
    'three-block-flat',
    'four-block',
    'four-block-flat',
    '2x2-block',
  ];

  const shifts = [
    0,
    0.1,
    0.4,
    0.5,
    0.6,
    0.8,
    0.9,
  ];

  for (let i = 0; i < images.length; i++) {
    for (let y = 0; y < shifts.length; y++) {
      const img = this.game.make.bitmapData();
      img.load(images[i]);
      img.shiftHSL(shifts[y]);
      this.game.cache.addBitmapData(`${images[i]}_${shifts[y] * 10}`, img);
    }
  }

  this.game.world.setBounds(0, -320, 1920, 1400);
  this.game.physics.arcade.checkCollision.up = false;

  this.state.blockGroup = this.game.add.physicsGroup();
  this.state.childBlockGroup = this.game.add.physicsGroup();
  this.state.blockGroup.enableBody = true;
  this.state.blockGroup.physicsBodyType = Phaser.Physics.ARCADE;

  const graphics = this.game.add.graphics(960, 0);
  graphics.lineStyle(20, 'rgba(129, 143, 149, 1)');
  graphics.moveTo(0, 0);
  graphics.lineTo(0, 1080);
  graphics.lineStyle(5, 'rgba(129, 143, 149, 0.75)');
  graphics.moveTo(-960, 950);
  graphics.lineTo(1920, 950);

  this.debugLR = this.game.add.sprite(0, -100, 'debugLine');
  this.debugLR.tint = '0xff0000';
  this.debugLR.alpha = 0.6;
  this.debugLB = this.game.add.sprite(970, -100, 'debugLine');
  this.debugLB.tint = '0x0000ff';
  this.debugLB.alpha = 0.6;

  this.spawnNewBlock('red');
  this.spawnNewBlock('blue');
}

module.exports = create;
