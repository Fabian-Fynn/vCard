var APP = window.APP || {};
APP.Games = APP.Games || {};
APP.Games.Pac = APP.Games.Pac || {};
APP.Games.Pac.functions = APP.Games.Pac.functions || {};

APP.Games.Pac.functions.update = (function(){

  function update() {
    APP.BaseGame.update();

    updateMaxerl();

    for(var idx in APP.Games.Pac.gameState.endzones) {
      APP.Games.Pac.gameState.endzones[idx].update();
    }
  }

  function updateMaxerl() {
    var state = APP.GameManager().currentGame.gameState;
    for(var i = 0; i < state.maxerl.length; i++) {
      if(state.maxerl[i].state.current !== state.maxerl[i].state.dead){
        APP.currentlyRunningGame.physics.arcade.collide(state.maxerl[i].sprite, state.mazeGroup,collide.bind({id: i,state: state}));
      } else {
        APP.currentlyRunningGame.physics.arcade.collide(state.maxerl[i].sprite,state.mazeGroup);
      }
      state.maxerl[i].update();
    }
    state.pac.update();
  }

  function collide(a,b) {
    this.state.maxerl[this.id].land();
  }

  return update;
})();