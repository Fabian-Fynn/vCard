function update() {
  this.baseFunctions.update.bind(this)();
  let i;

  if (!this.state.ranInit) {
    this.game.physics.arcade.isPaused = false;
    this.state.ranInit = true;
  }

  for (i = 0; i < this.state.maxerl.length; i++) {
    const max = this.state.maxerl[i];
    if (!max.state.is(max.state.dead)) {
      this.game.physics.arcade.collide(
          max.sprite, this.state.snakeGroup,
          () => { max.land(); }, null, this
          );

      if (max.sprite.body.onFloor()) {
        max.die();
        this.checkWin();
      }

      max.update();
    }
  }

  for (i = 0; i < this.state.snakes.length; i++) {
    this.game.physics.arcade.collide(
        this.state.food, this.state.snakes[i].sprite,
        () => {
          this.state.snakes[1 - i].poison();
          this.state.food.body.velocity.x = 0;
          this.state.food.body.velocity.y = 0;
          this.repositionFood();
        }, null, this
        );
    this.state.snakes[i].update();
  }

  this.state.tickCounter++;
}

module.exports = update;
