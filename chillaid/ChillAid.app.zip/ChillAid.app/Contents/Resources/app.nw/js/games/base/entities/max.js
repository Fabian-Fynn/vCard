const Ms = require('./max_state.js');
const Ma = require('./max_actions.js');
const utils = require('../../../modules/utils.js');

function handleButtonChange(data) {
  function handleUp(d) {
    if (d.val) {
      this.jump();
    }
  }

  function handleRight(d) {
    if (d.val) {
      this.shove();
    }
  }

  function handleDown(d) {
    if (d.val) {
      this.crouching = true;
    } else {
      this.crouching = false;
    }
    const state = this.controller.state;
    if (!state.keyStates.dir) {
      this.stand();
    } else {
      this.run(state.keyStates.dir);
    }
  }

  switch (data.key) {
    case 'up': handleUp.bind(this)(data); break;
    case 'right': handleRight.bind(this)(data); break;
    case 'down': handleDown.bind(this)(data); break;
    case 'left': break;
    default: break;
  }
}

function handleDirChange(data) {
  if (!data.keyStates.dir) {
    this.stand();
  } else {
    this.run(data.keyStates.dir);
  }
}

class Max extends Ma {
  constructor(config) {
    super();
    this.parent = config.parent;
    this.state = new Ms();
    this.controller = config.controller;
    this.ctrlEmitter = this.controller.emitter;
    this.team = config.team;
    this.name = config.name;
    this.sprite = this.createSprite(config);
    this.sprite.max = this;
    this.crouching = false;
    this.disabled = false;
    this.walljumping = false;
    this.reviveSprite = null;
    this.collisionSprite = null;
    this.reviveTick = 0;

    this.timeouts = {};

    this.buttonChangeHandler = handleButtonChange.bind(this);
    this.dirChangeHandler = handleDirChange.bind(this);

    this.addCtrlListeners();
  }

  addCtrlListeners() {
    this.disabled = false;
    this.ctrlEmitter.on('button_change', this.buttonChangeHandler);
    this.ctrlEmitter.on('dir_change', this.dirChangeHandler);
  }

  removeCtrlListeners() {
    this.disabled = true;
    this.ctrlEmitter.removeListener('button_change', this.buttonChangeHandler);
    this.ctrlEmitter.removeListener('dir_change', this.dirChangeHandler);
  }

  removeTimeouts() {
    for (let idx in this.timeouts) {
      clearTimeout(this.timeouts[idx]);
    }
  }

  stopAnimations() {
    this.sprite.animations.stop('walk');
    this.sprite.animations.stop('crouchMove');
    this.sprite.animations.stop('jump');
    this.sprite.animations.stop('fall');
    this.sprite.animations.stop('slide');
    this.sprite.animations.stop('die');
    this.sprite.animations.stop('shove');
  }

  updateNamePosition() {
    this.name.x = this.sprite.x - this.name.width / 2;
    if (this.crouching &&
      (this.state.current === this.state.stand || this.state.current === this.state.run)) {
      this.name.y = this.sprite.y - 90;
    } else {
      this.name.y = this.sprite.y - 125;
    }
  }

  updateReviveSprite() {
    // 3 * 60 = 180 ticks bis revive
    if (this.reviveSprite !== null) {
      const jump = (this.sprite.body.bottom - this.reviveSprite.y) / (180 - this.reviveTick);
      this.reviveSprite.y += Math.abs(jump);
      if (this.reviveSprite.alpha < 0.75) {
        this.reviveSprite.alpha += 0.0025;
      }
      if (this.reviveSprite.y >= this.sprite.body.y + this.sprite.body.height) {
        this.reviveSprite.destroy();
        this.reviveSprite = null;
        this.reviveTick = 0;
        this.revive();
      }
      this.reviveTick += 1;
    }
  }

  update() {
    this.updateReviveSprite();
    this.updateNamePosition();
    this.updateAirPosition();
    this.updateSliding();
  }

  updateAirPosition() {
    if (this.sprite.body.touching.down || this.sprite.body.onFloor()) {
      this.collisionSprite = null;
      this.land();
    } else if (this.sprite.body.touching.left || this.sprite.body.touching.right) {
      // this.slide();
    } else if (this.sprite.body.velocity.y >= 0) {
      this.fall();
    }

    const state = this.controller.state;
    if (!this.disabled && state.keyStates.dir) {
      const directionMultiplier = this.sprite.body.direction === 0 ? -1 : 1;
      this.sprite.scale.x = directionMultiplier;

      const vx = directionMultiplier * 460 * (state.keyStates.dir.intensity / (this.crouching ? 2 : 1)) / 100;
      if (vx < this.sprite.body.velocity.x) {
        this.sprite.body.velocity.x -= 30;
      } else if (vx > this.sprite.body.velocity.x) {
        this.sprite.body.velocity.x += 30;
      }
    }
  }

  updateSliding() {
    if (this.collisionSprite !== null) {
      const distance = Math.abs(this.sprite.body.x - this.collisionSprite.body.x);
      const leftFromSprite = (this.sprite.body.x < this.collisionSprite.body.x);
      const maxDis = leftFromSprite ? this.sprite.body.width : this.collisionSprite.body.width;
      if (distance > maxDis + 3) {
        this.stand();
        this.collisionSprite = null;
      }
    }
  }

  startRevive(time) {
    this.reviveSprite = this.parent.game.add.sprite(
      this.sprite.body.x + this.sprite.body.width / 2,
      this.sprite.body.y - time * 60,
      this.controller.sprite
    );
    this.reviveSprite.anchor.setTo(0.5, 1);
    this.reviveSprite.frame = 17;
    this.reviveSprite.alpha = 0;
    this.reviveSprite.tint = `0x${utils.rgbToHex(this.team.color)}`;

    if (this.sprite.body.direction === 1) {
      this.reviveSprite.scale.x = 1;
    } else {
      this.reviveSprite.scale.x = -1;
    }
  }

  revive() {
    if (this.reviveSprite === null && this.state.change(this.state.stand)) {
      this.controller.sendData('vibrate', [150, 40, 150]);
      this.regainControl();
    }
  }

  createSprite(config) {
    const sprite = this.parent.game.add.sprite(config.x, config.y, config.controller.sprite);
    sprite.animations.add('walk', [1, 2, 3], 10, true);
    sprite.animations.add('crouchMove', [13, 14, 15], 10, true);
    sprite.animations.add('jump', [4, 5, 6], 25, false);
    sprite.animations.add('fall', [7, 8, 9], 35, false);
    sprite.animations.add('slide', [16], 35, false);
    sprite.animations.add('shove', [18, 19, 20], 15, false);
    sprite.animations.add('die', [10, 11, 12], 35, false);
    sprite.anchor.setTo(0.5, 1);
    sprite.scale.x = config.direction === 0 ? -1 : 1;

    sprite.tint = `0x${utils.rgbToHex(this.team.color)}`;

    this.parent.game.physics.arcade.enable(sprite);
    sprite.key = `max${utils.uid()}`;

    sprite.body.collideWorldBounds = true;

    if (!config.collideEverywhere) {
      sprite.body.checkCollision.left = false;
      sprite.body.checkCollision.right = false;
      sprite.body.checkCollision.up = false;
    }

    sprite.body.gravity.y = 1600;
    sprite.body.direction = config.direction;
    sprite.body.velocity.x = 0;
    sprite.body.velocity.y = 0;
    sprite.body.setSize(30, 93, 0, -4);

    return sprite;
  }
}

module.exports = Max;
