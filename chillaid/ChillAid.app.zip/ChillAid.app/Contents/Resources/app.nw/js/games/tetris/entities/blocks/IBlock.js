const utils = require('../../../../modules/utils.js');
const BaseBlock = require('../BaseBlock.js');

class IBlock extends BaseBlock {
  constructor(options) {
    super(options);

    const rotationArr = typeof options.fixedRotation === 'object' ? options.fixedRotation : [0, 90];
    const rotation = rotationArr[utils.ranInt(0, rotationArr.length - 1)];
    const sprites = [{
      name: (rotation === 90) ? 'four-block-flat_4' : 'four-block_4',
      vectors: [[0, 0, 0]],
    }];

    const slot = options.slot;

    this.config.x = (slot * this.config.blockWidth) + this.config.blockWidth / 2;
    if (slot > 18) {
      this.config.x += 20;
    }
    if (rotation === 90) {
      this.config.x += this.config.blockWidth * 1.5;
    }
    this.createSprite(sprites);
    this.keepInAreaBounds();
  }
}

module.exports = IBlock;
