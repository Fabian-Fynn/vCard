
function update() {
  this.baseFunctions.update.bind(this)();

  updateMaxerl.bind(this)();
}

function updateMaxerl() {
  for (var i = 0; i < this.state.maxerl.length; i++) {
    if (this.state.maxerl[i].state.current.name !== this.state.maxerl[i].state.dead.name) {
      this.state.maxerl[i].update();
    }
  }
}

module.exports = update;
