process.on('uncaughtException', (e) => { console.log(e.stack); });

global.$ = global.jQuery = $;
global.p2 = p2;
global.PIXI = PIXI;
global.Phaser = Phaser;
global.console = console;
global.w = window;
global.windowIsActive = true;

const nwgui = require('nw.gui');

const hm = require('./js/modules/frontend/hide_mouse.js');
hm();

// $('#debug-tools').click(() => {
//   nwgui.Window.get().showDevTools();
// });

const s = require('./js/modules/connectivity/server.js');
s.init();

const w = nwgui.Window.get();
w.on('close', function() {
  s.close();
  this.close(true);
});

// $('#debug-reload').click(function () {
//   s.close();
//   chrome.runtime.reload();
// });

const ip = require('./js/modules/connectivity/ip.js');
$('#game-id-display').html(`IP: ${ip.getLocalIp()}`);

const unitSwitcher = require('./js/modules/frontend/unit_switcher.js');
unitSwitcher.init();

const Cm = require('./js/modules/game_management/controller_manager.js');
global.controllerManager = new Cm(s.getConnectionPoint());

const gm = require('./js/modules/game_management/game_manager.js');
const tm = require('./js/modules/game_management/team_manager.js');
$('#startGame').click(() => {
  if (!tm.teamMinimumReached(1)) {
    return;
  }
  gm.startNextGame();
});

require('./js/modules/frontend/select_button.js').init();
$('.select-game').click((e) => {
  gm.selectGame($(e.delegateTarget).data('game'));
});

$('.complete-wrapper').addClass('initialized');

const igm = require('./js/modules/frontend/in_game_menu.js');
igm.init();

const splash = require('./js/modules/frontend/splash.js');
splash();

const notify = require('./js/modules/frontend/notify.js');

const KeyCombination = require('./js/modules/frontend/key_combination.js');

new KeyCombination([68, 66, 71], () => {
  gm.selectGame('debug');
  notify.enqueue('Sanbox mode enabled!');
});

setTimeout(() => {
  $('#intro-animation').addClass('out');
}, 1300);
