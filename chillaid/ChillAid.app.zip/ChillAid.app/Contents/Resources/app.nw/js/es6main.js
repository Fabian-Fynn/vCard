// APP.debug = {
//   debugControllerIDs: [],
//   godMode: false
// };

global.$ = global.jQuery = $;
global.p2 = p2;
global.PIXI = PIXI;
global.Phaser = Phaser;
global.console = console;
global.w = window;

$('#debug-reload').click(function() {
	saveWindowState();
	chrome.runtime.reload()
});

$('#debug-tools').click(function() {
	require('nw.gui').Window.get().showDevTools();
});

// (function() {
	var splash = require('./js/modules/frontend/splash.js');
	splash();

	var ip = require('./js/modules/connectivity/ip.js');
	$('#game-id-display').html('ID: ' + ip.getEncodedLocalIp());

	var unitSwitcher = require('./js/modules/frontend/unit_switcher.js');
	unitSwitcher.init();

	var s = require('./js/modules/connectivity/server.js');
	s.init();

	var cm = require('./js/modules/game_management/controller_manager.js');
	global.controllerManager = new cm(s.getConnectionPoint());

	var gm = require('./js/modules/game_management/game_manager.js');
	$('#startGame').click(() => {
		gm.startNextGame();
	});

// })();


// $('#debug-controllers').click(function() {
//   if(!APP.debug.debugControllers){
//     APP.ControllerStates.addDebugController('red'); APP.GameManager().addPlayerToTeam(1,'red');
//     APP.ControllerStates.addDebugController('blue'); APP.GameManager().addPlayerToTeam(2,'blue');

//     APP.debug.debugControllers = true;
//     $(this).addClass('enabled');
//   }
// });

// $('#debug-god-mode').click(function() {
//   if(!APP.debug.godMode){
//     APP.debug.godMode = true;
//     $(this).addClass('enabled');
//   } else {
//     APP.debug.godMode = false;
//     $(this).removeClass('enabled');
//   }
// });

// $('#debug-maximize').click(function() {
//   var window = require('nw.gui').Window.get();
//   window.maximize();

//   console.log(window.isFullscreen);
//   if(window.isFullscreen) {
//     $(this).removeClass('enabled');
//     window.isFullscreen = false;
//   } else {
//     $(this).addClass('enabled');
//     window.isFullscreen = true;
//   }
// });

$('.complete-wrapper').addClass('initialized');