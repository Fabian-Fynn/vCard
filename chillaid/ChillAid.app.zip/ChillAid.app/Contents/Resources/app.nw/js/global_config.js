module.exports = {
	                                        minPlayers: 1,
	                                        maxPlayers: 8,
};
