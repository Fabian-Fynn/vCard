function uid(len = 7) {
  return Math.random().toString(35).substr(2, len);
}
function contains(needle) {
  const findNaN = needle !== needle;
  let indexOf;

  if (!findNaN && typeof Array.prototype.indexOf === 'function') {
    indexOf = Array.prototype.indexOf;
  } else {
    indexOf = function (needle) {
      let i = -1;
      let index = -1;

      for (i = 0; i < this.length; i++) {
        const item = this[i];

        if ((findNaN && item !== item) || item === needle) {
          index = i;
          break;
        }
      }

      return index;
    };
  }

  return indexOf.call(this, needle) > -1;
}

function calculateAngle(x1, y1, x2, y2) {
  return Math.atan2(y2 - y1, x2 - x1);
}

function rotateVec(cx, cy, x, y, rad) {
  const radians = rad;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  const nx = (cos * (x - cx)) + (sin * (y - cy)) + cx;
  const ny = (cos * (y - cy)) - (sin * (x - cx)) + cy;
  return [nx, ny];
}

function ranInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function dist(x1, y1, x2, y2) {
  const vx = Math.pow(x1 - x2, 2);
  const vy = Math.pow(y1 - y2, 2);
  return Math.sqrt(vx + vy);
}

function rgbToHex(color) {
  let r = color.r.toString(16);
  let g = color.g.toString(16);
  let b = color.b.toString(16);

  r = r.length === 1 ? `0${r}` : r;
  g = g.length === 1 ? `0${g}` : g;
  b = b.length === 1 ? `0${b}` : b;

  return r + g + b;
}

function shuffle(a) {
  let j;
  let x;
  let i;
  for (i = a.length; i; i -= 1) {
    j = Math.floor(Math.random() * i);
    x = a[i - 1];
    a[i - 1] = a[j];
    a[j] = x;
  }
}

function remove(needle) {
  const index = contains.call(this, needle);
  if (index) {
    this.splice(this.indexOf(needle), 1);
  }
}

module.exports = {
  uid,
  contains,
  calculateAngle,
  rotateVec,
  ranInt,
  dist,
  rgbToHex,
  shuffle,
  remove,
};
