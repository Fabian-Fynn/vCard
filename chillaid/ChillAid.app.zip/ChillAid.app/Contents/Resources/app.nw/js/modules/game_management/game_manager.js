const debug = require('../../games/debug/game.js');
const tetris = require('../../games/tetris/game.js');
const snake = require('../../games/snake/game.js');
const pac = require('../../games/pac/game.js');
const utils = require('../utils.js');
const tm = require('./team_manager.js');
const mn = require('../frontend/menu_navigator.js');
const Pm = require('../../modules/game_management/points_manager.js');
const us = require('../frontend/unit_switcher.js');
const pd = require('./points_display.js');

class GameManager {
  constructor() {
    this.games = [tetris, snake, pac];
    this.selectedGame = 'ran';
    this.selectGame(this.selectedGame);
    this.activeGame = null;
    this.pointManager = new Pm();
  }

  selectGame(id) {
    if (typeof id === 'number') {
      this.gameQueue = [this.games[id]];
    } else if (id === 'debug') {
      this.gameQueue = [debug];
    } else {
      this.gameQueue = $.extend([], this.games); // All games randomly
      utils.shuffle(this.gameQueue);
    }
    this.selectedGame = id;
  }

  startNextGame() {
    mn.setAvailability(false);
    if (tm.teamMinimumReached(3)) {
      $('.snake .controllMode').css('display', 'block');
      $('.snake .randomMode').css('display', 'none');
    } else {
      $('.snake .controllMode').css('display', 'none');
      $('.snake .randomMode').css('display', 'block');
    }
    if (!tm.teamMinimumReached(1)) {
      us.switchToUnit('lobby');
      this.selectGame(this.selectedGame);
      this.displayTotal();
    } else {
      const NextGame = this.gameQueue.splice(0, 1)[0];
      this.activeGame = new NextGame();
    }
  }

  endCurrentGame() {
    const mouse = this.activeGame.game.input.mouse;
    global.w.removeEventListener('mouseout', mouse._onMouseOutGlobal, true);
    this.activeGame.game.destroy();
    this.activeGame = null;

    $('.splash').removeClass('loading');
    $('.splash').removeClass('hidden');

    if (typeof this.selectedGame === 'number' || this.gameQueue.length === 0) {
      // Show final points
      us.switchToUnit('lobby');
      this.selectGame(this.selectedGame);
      this.displayTotal();
    } else {
      this.startNextGame();
    }
  }

  displayTotal() {
    const totalPoints = global.gm.pointManager.getGamePoints();
    const $roundContainer = $('#lobby .points.total .rounds');
    $roundContainer.empty();
    for (let idx in this.pointManager.roundPoints) {
      $roundContainer.append([
        `<div class="round md-bs-4mm ${idx}" data-idx=${idx}>`,
        `<div class="red" data-points="${this.pointManager.roundPoints[idx].red}">`,
        '<div class="bar red"></div></div>',
        '<div class="name md-6mm"><div class="icon"></div></div>',
        `<div class="blue" data-points="${this.pointManager.roundPoints[idx].blue}">`,
        '<div class="bar blue"></div></div>',
        '</div>',
      ].join(''));
    }
    const numRounds = Object.keys(this.pointManager.roundPoints).length;

    if (numRounds > 0) {
      $('#lobby .points.total .game .red').data('points', totalPoints.red).html(0);
      $('#lobby .points.total .game .blue').data('points', totalPoints.blue).html(0);
      $('#lobby .points.total').addClass('visible');

      setTimeout(pd.displayTotalPoints, 1000);
      setTimeout(() => {
        $('#lobby .points.total').removeClass('visible');
        mn.setAvailability(true);
        this.pointManager = new Pm();
      }, numRounds * 3000 + 3000);
    } else {
      mn.setAvailability(true);
      this.pointManager = new Pm();
    }
  }
}


const gmi = new GameManager();

global.gm = gmi;

module.exports = gmi;
