const events = require('events');
const tm = require('./team_manager.js');
const utils = require('../utils.js');

class Controller {
  constructor(socket) {
    this.state = {
      skt: null,
      name: 'guest',
      ready: false,
      team: false,
      keyStates: {
        up: false,
        down: false,
        left: false,
        right: false,
        dir: false,
      },
      lastPing: 'nA',
      hasActiveKeys: false,
    };
    this.menuController = false;
    this.state.skt = socket;
    this.id = utils.uid();
    this.emitter = new events.EventEmitter();
    this.state.keyStates.lastStrongDir = false;
    this.disconnectTimeout = setTimeout(this.kick.bind(this), 8000);

    if (socket !== null) {
      this.ping();
      this.addListeners();
    }
  }

  kick() {
    this.state.skt.disconnect();
  }

  ping() {
    if (this.disconnectTimeout !== null) {
      clearTimeout(this.disconnectTimeout);
    }
    this.disconnectTimeout = setTimeout(this.kick.bind(this), 8000);

    this.state.skt.on('myPong', (time) => {
      this.state.skt.removeAllListeners('myPong');
      this.state.lastPing = $.now() - time;
      setTimeout(this.ping.bind(this), 1000);
    });
    this.state.skt.emit('myPing', $.now());
  }

  addListeners() {
    this.state.skt.on('join_team', (team) => {
      if (tm.add(this.id, team)) {
        this.state.team = team;
        const c = tm.teams[team].color;
        const colorString = `rgb(${c.r},${c.g},${c.b})`;
        this.state.skt.emit('team_joined', colorString);
        this.emitter.emit('some_change');
      }
    });

    this.state.skt.on('keyEvent', (data) => {
      this.updateKey(data.key, data.state);
    });

    this.state.skt.on('set_name', (name) => {
      this.setName(name);
      this.emitter.emit('some_change');
    });
  }

  setName(name) {
    if (this.state.team && this.state.name !== name) {
      notify.enqueue(`${this.state.name} is now known as ${name}`);
    }
    this.state.name = name;
    this.emitter.emit('name_set', this.state);
  }

  sendData(msg, data) {
    if (this.state.skt !== null) {
      if (typeof data === 'undefined') {
        this.state.skt.emit(msg);
      } else {
        this.state.skt.emit(msg, data);
      }
    }
  }

  updateKey(key, val) {
    this.state.keyStates[key] = val;
    if (this.state.keyStates.dir !== false ||
      this.state.keyStates.up ||
      this.state.keyStates.down ||
      this.state.keyStates.left ||
      this.state.keyStates.right) {
      this.state.hasActiveKeys = true;
    } else {
      this.state.hasActiveKeys = false;
    }

    if (key === 'dir' && val !== false) {
      const angle = val.angle;
      let dirString = '';
      this.state.keyStates.dir.translatedDir = {
        up: false,
        down: false,
        left: false,
        right: false,
      };
      if (angle >= 315 || angle < 45) {
        this.state.keyStates.dir.translatedDir.up = true;
        dirString = 'up';
      } else if (angle < 135) {
        this.state.keyStates.dir.translatedDir.right = true;
        dirString = 'right';
      } else if (angle < 225) {
        this.state.keyStates.dir.translatedDir.down = true;
        dirString = 'down';
      } else {
        this.state.keyStates.dir.translatedDir.left = true;
        dirString = 'left';
      }

      if (val.intensity > 50 && this.state.keyStates.lastStrongDir !== dirString) {
        this.state.keyStates.lastStrongDir = dirString;
        this.emitter.emit('strong_dir_change', dirString, this);
      }
      if (val.intensity <= 50) {
        this.state.keyStates.lastStrongDir = false;
      }
      this.emitter.emit('dir_change', this.state);
    } else if (key === 'dir') {
      this.emitter.emit('dir_change', this.state);
      this.state.keyStates.lastStrongDir = false;
    } else {
      this.emitter.emit('button_change', { key, val });
    }
  }
}

module.exports = Controller;
