const actions = {
  clickMe() {
    if (this.currentItem !== null) {
      if (this.currentItem.find('.click-target').length > 0) {
        this.currentItem.find('.click-target').trigger('click');
      } else {
        this.currentItem.trigger('click');
      }
    }
  },
};

class MenuNavigator {
  constructor(config) {
    this.selector = config.selector;
    this.startItemId = config.startId;
    this.currentItem = null;
    this.available = true;

    this.switchTo($(this.startItemId));
    this.currentItem.removeClass('menu-navigator-focus');
  }

  disable(emitter) {
    if (emitter !== null) {
      this.currentItem.removeClass('menu-navigator-focus');
      emitter.removeListener('dir_change', this.findNext.bind(this));
      emitter.removeListener('button_change', this.handleButtonPress.bind(this));
    }
  }

  setAvailability(available) {
    this.available = available;
  }

  enable(emitter) {
    if (emitter !== null) {
      this.currentItem.addClass('menu-navigator-focus');
      emitter.on('strong_dir_change', this.findNext.bind(this));
      emitter.on('button_change', this.handleButtonPress.bind(this));
    }
  }

  findNext(dirString, controller) {
    const dir = controller.state.keyStates.dir;

    if (dir === false || dir.intensity < 40 || this.available === false) {
      return;
    }

    const angle = (90 - dir.angle) * -1;
    const allItems = $(this.selector);
    let target;

    if (dirString === 'down' && $(allItems[0]).is(this.currentItem)) {
      if (angle > 45 && angle < 90) {
        target = $(allItems[this.currentItem.data('targets').downRight]);
      } else {
        target = $(allItems[this.currentItem.data('targets').downLeft]);
      }
    } else {
      for (let key in dir.translatedDir) {
        if (dir.translatedDir[key]) {
          if (this.currentItem.data('targets')) {
            target = $(allItems[this.currentItem.data('targets')[key]]);
          }
          break;
        }
      }
    }

    if (target !== false) {
      this.switchTo(target);
    }
  }

  switchTo(obj) {
    if (!obj || obj.length === 0) {
      return;
    }

    this.currentItem = obj;
    $(this.selector).removeClass('menu-navigator-focus');
    this.currentItem.addClass('menu-navigator-focus');
  }

  handleButtonPress(data) {
    if (data.key !== 'down' || !data.val || this.available === false) {
      return;
    }
    const action = actions[this.currentItem.data('menuaction')];
    if (typeof action === 'function') {
      action.bind(this)();
    }
  }
}

module.exports = new MenuNavigator({
  selector: '.main-menu-navigator',
  startId: '#startGame',
});
