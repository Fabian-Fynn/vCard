function switchToUnit(id) {
  $('.unit.game .ingame-menu').addClass('hidden');
  $('.unit.game .ingame-points').addClass('hidden');
  const offset = $(`#${id}`).offset().top + Math.abs($('#unit-container').offset().top);
  const times = Math.round(offset / $(global.w).height());
  const cssString = `translateY(${-100 * times}vh)`;
  $('#unit-container').css('transform', cssString);
}

function init() {
  $('.unit-switch').click((e) => {
    const id = $(e.delegateTarget).data('unit');
    switchToUnit(id);
  });
}


module.exports = Object.freeze({
  switchToUnit,
  init,
});
