const lastDrawn = {
  red: [false, false, false, false],
  blue: [false, false, false, false],
};

function updateControllers(ctrls) {
  if (global.gm.activeGame !== null) {
    return;
  }

  $('.player-card.navigator').removeClass('navigator');

  const directions = ['up', 'down', 'left', 'right'];
  for (let controllerId in ctrls) {
    const ctrl = ctrls[controllerId].state;

    if (ctrls[controllerId].menuController) {
      $(`#${ctrls[controllerId].id}`).addClass('navigator');
    }

    for (let i = 0; i < directions.length; i++) {
      const key = directions[i];
      if (ctrl.keyStates[key]) {
        ctrl.interface.dir[key].addClass('active');
      } else {
        ctrl.interface.dir[key].removeClass('active');
      }
    }

    ctrl.interface.name.html(` ${ctrl.name}`);

    if (ctrl.keyStates.dir) {
      ctrl.interface.degCursor.css({
        transform: `rotate(${ctrl.keyStates.dir.angle}deg)`,
        display: 'block',
      });
    } else {
      ctrl.interface.degCursor.css({
        display: 'none',
      });
    }
  }
}

function drawControllers(ctrls) {
  const controllerDebugDiv = $('#controllers-debug');

  controllerDebugDiv.empty();

  ctrls = $.extend({}, ctrls);

  for (let idx in lastDrawn) {
    for (let i = 0; i < lastDrawn[idx].length; i++) {
      if (lastDrawn[idx][i] === false) {
        continue;
      }
      if (Object.keys(ctrls).indexOf(lastDrawn[idx][i]) !== -1 &&
        ctrls[lastDrawn[idx][i]].team === idx) {
        delete ctrls[lastDrawn[idx][i]];
      } else {
        $(`.team-${idx}-p${i + 1} .front .name`).html('open');
        $(`.team-${idx}-p${i + 1}`).addClass('open');
        $(`.team-${idx}-p${i + 1}`).attr('id', '');
        lastDrawn[idx][i] = false;
      }
    }
  }

  for (let idx in ctrls) {
    const ctrl = ctrls[idx].state;
    const controllerId = ctrls[idx].id;
    const team = ctrl.team;
    const name = ctrl.name;

    if (team === 'red' || team === 'blue') {
      for (let i = 0; i < lastDrawn[team].length; i++) {
        if (lastDrawn[team][i] === false) {
          $(`.team-${team}-p${i + 1} .front .name`).html(name);
          $(`.team-${team}-p${i + 1}`).removeClass('open');
          $(`.team-${team}-p${i + 1}`).attr('id', idx);
          lastDrawn[team][i] = idx;
          break;
        }
      }
    }

    ctrl.interface = {
      name: $(`#${controllerId} .name`),
      degCursor: $(`#${controllerId} .cursor.degree span`),
      dir: {
        up: $(`#${controllerId} .cursor.up`),
        right: $(`#${controllerId} .cursor.right`),
        down: $(`#${controllerId} .cursor.down`),
        left: $(`#${controllerId} .cursor.left`),
      },
    };
  }
  updateControllers(ctrls);
  $(global.w).trigger('resize');
}

module.exports = Object.freeze({
  drawControllers,
  updateControllers,
});
