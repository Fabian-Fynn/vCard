function init(canvas) {
  const originalWidth = canvas.width();
  const originalHeight = canvas.height();
  $(global.w).resize(() => {
    const parentWidth = canvas.parent().width();
    const parentHeight = canvas.parent().height();
    let perc = parentWidth / originalWidth;
    if (originalHeight * perc > parentHeight) {
      perc = parentHeight / originalHeight;
    }
    canvas.css('transform-origin', '0 0');
    canvas.css('transform', `scale(${perc}) translate(-50%,-50%)`);
  });
  $(global.w).trigger('resize');
}

module.exports = Object.freeze({
  init,
});
