const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const diont = require('diont')();
const os = require('os');

const service = {
  name: `${os.hostname()}`.replace('.local', ''),
  port: '8080',
};

function init() {
  app.get('/', (req, res) => {
    res.send('I don\'t think you should be here...');
  });

  app.get('/areyouthere', (req, res) => {
    res.send('Yes, I am here. Are you?');
  });

  http.listen(8080, () => {
    diont.announceService(service);
  });
}

function getConnectionPoint() {
  return io;
}

function close() {
  diont.renounceService(service);
  for (let idx in io.sockets.sockets) {
    io.sockets.sockets[idx].disconnect(true);
  }
  io.close();
  http.close();
}

module.exports = Object.freeze({
  init,
  getConnectionPoint,
  close,
});
