const messages = [
  'Powered by caffeine',
  'Made with Love and Caffeine',
  'It\'s weird but it works...',
  'Unfinished? It\'s called artistic freedom!',
  'Conneging...',
  'This.that = this;',
  'The cake is alive!',
  'Coding > Sleeping',
  'Sleep? Now that\'s a word I havn\'t heard in a while.',
  'while (1) { code(); sleep(); }',
  'Code is love, code is live!',
  'Habedahabedahabeda',
  '4 8 15 16 23 42',
];

function init() {
  $('#splash').html(messages[Math.floor(Math.random() * messages.length)]);
  $('#splash').addClass('show');
}

module.exports = init;
