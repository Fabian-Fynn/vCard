class PointsManager {
  constructor() {
    this.gamePoints = {
      red: 0,
      blue: 0,
    };
    this.roundPoints = {};
  }

  creatRoundIfDoesNotExist(round) {
    if (round !== false && typeof this.roundPoints[round] === 'undefined') {
      this.roundPoints[round] = {
        red: 0,
        blue: 0,
      };
    }
  }

  addPoint({ game = false, round = false, team }) {
    this.creatRoundIfDoesNotExist(round);
    if (round !== false) {
      this.roundPoints[round][team] += 1;
    } else if (game === true) {
      this.gamePoints[team] += 1;
    }
  }

  setPoints({ round, team, points }) {
    this.creatRoundIfDoesNotExist(round);
    this.roundPoints[round][team] = points;
  }

  subtractPoint({ game = false, round = false, team }) {
    this.creatRoundIfDoesNotExist(round);
    if (round !== false) {
      this.roundPoints[round][team] -= 1;
    } else if (game === true) {
      this.gamePoints[team] -= 1;
    }
  }

  getRoundPoints(round) {
    this.creatRoundIfDoesNotExist(round);
    return this.roundPoints[round];
  }

  getGamePoints() {
    return this.gamePoints;
  }

  teamHasXRoundPoints(round, points) {
    if (this.roundPoints[round].red === points) {
      return 'red';
    }
    if (this.roundPoints[round].blue === points) {
      return 'blue';
    }
    return false;
  }
}

module.exports = PointsManager;
