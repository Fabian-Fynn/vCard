const Controller = require('./controller.js');
const ti = require('../frontend/team_interface.js');
const tm = require('./team_manager.js');
const mm = require('../frontend/menu_navigator.js');


class ControllerManager {
  constructor(connectionPoint) {
    this.io = connectionPoint;
    this.controllers = {};

    this.io.on('connection', this.handleConnection.bind(this));
  }

  get(id) {
    return this.controllers[id];
  }

  handleConnection(s) {
    if (Object.keys(this.controllers).length >= 8) {
      s.disconnect();
      return;
    }
    const ctrl = new Controller(s);
    if (Object.keys(this.controllers).length === 0) {
      mm.enable(ctrl.emitter);
      ctrl.menuController = true;
      ctrl.state.skt.emit('set_as_menu_controller');
    }

    this.controllers[ctrl.id] = ctrl;

    s.emit('controller:accepted', {
      teams: ['red', 'blue'],
      id: ctrl.id,
    });
    ti.drawControllers(this.controllers);

    s.on('disconnect', () => {
      if (typeof this.controllers[ctrl.id] !== 'undefined') {
        tm.remove(ctrl.id);
        this.controllers[ctrl.id].emitter.emit('disconnect');
        notify.enqueue({
          message: ' left the game',
          controllerId: ctrl.id,
          type: 'player',
        });
        delete this.controllers[ctrl.id];
        if (ctrl.menuController) {
          mm.disable(ctrl.emitter);
          const ctrlKeys = Object.keys(this.controllers);
          if (ctrlKeys.length > 0) {
            this.controllers[ctrlKeys[0]].state.skt.emit('set_as_menu_controller');
            this.controllers[ctrlKeys[0]].menuController = true;
            mm.enable(this.controllers[ctrlKeys[0]].emitter);
            notify.enqueue({
              message: ' has menu control',
              controllerId: ctrlKeys[0],
              type: 'player',
            });
          }
        }
      }
      ti.drawControllers(this.controllers);
    });

    ctrl.emitter.on('some_change', () => {
      ti.drawControllers(this.controllers);
    });
    ctrl.emitter.on('dir_change', () => {
      ti.updateControllers(this.controllers);
    });
    ctrl.emitter.on('button_change', () => {
      ti.updateControllers(this.controllers);
    });
  }
}


module.exports = ControllerManager;
