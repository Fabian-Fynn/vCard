
class KeyCombination {
  constructor(keyCodes, callback) {
    this.keyCodes = keyCodes;
    this.keyTimeout = null;
    this.setKeyMap();
    this.callback = callback;

    $(global.w.document).keydown((e) => {
      if (e.keyCode in this.keyMap) {
        if (this.keyTimeout !== null) {
          clearTimeout(this.keyTimeout);
        }
        this.keyMap[e.keyCode] = true;
        if (this.allKeysAreDown()) {
          this.callback();
        }
        this.keyTimeout = setTimeout(this.setKeyMap.bind(this), 300);
      }
    });
  }

  setKeyMap() {
    this.keyMap = {};
    for (let i = 0; i < this.keyCodes.length; i++) {
      this.keyMap[this.keyCodes[i]] = false;
    }
  }

  allKeysAreDown() {
    for (let idx in this.keyMap) {
      if (this.keyMap[idx] !== true) {
        return false;
      }
    }
    return true;
  }
}

module.exports = KeyCombination;
