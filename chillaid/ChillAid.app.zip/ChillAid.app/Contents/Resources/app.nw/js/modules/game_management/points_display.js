function showRound(rounds) {
  if (rounds.length === 0) {
    return;
  }
  const $round = $(rounds.splice(0, 1));
  $round.addClass('visible');
  const numVisible = $('.points.total .rounds .round.visible').length;
  $('.points.total .rounds').css('transform', `translateY(-${11.5 * numVisible}vh)`);

  const pRed = $round.find('.red').data('points');
  const pBlue = $round.find('.blue').data('points');
  const percRed = Math.ceil((pRed / (pRed + pBlue)) * 100);
  const percBlue = Math.ceil((pBlue / (pRed + pBlue)) * 100);
  $round.find('.red .bar').css('width', `${percRed}%`);
  $round.find('.blue .bar').css('width', `${percBlue}%`);

  const hasWinner = (pRed !== pBlue);
  if (hasWinner) {
    const winner = pRed > pBlue ? 'red' : 'blue';
    const gameName = $round.data('idx').toLowerCase();
    $round.find('.name').addClass(winner);
    $round.find('.name').addClass(gameName);

    const totalP = Number.parseInt($(`.points.total .game .${winner}`).html(), 10) + 1;
    setTimeout(() => {
      $(`.points.total .game .${winner}`).html(totalP);
      $round.find('.icon').css('opacity', 1);
    }, 1000);
  } else {
    $round.find('.name').addClass('tied');
    setTimeout(() => {
      $round.find('.icon').css('opacity', 1);
    }, 1000);
  }

  if (rounds.length > 0) {
    setTimeout(() => {
      showRound(rounds);
    }, 3000);
  } else {
    setTimeout(() => {
      const totalR = $('#lobby .points.total .game .red').data('points');
      const totalB = $('#lobby .points.total .game .blue').data('points');
      if (totalR !== totalB) {
        const totalWinner = totalR > totalB ? 'red' : 'blue';
        $('.confetti-emitter').addClass(totalWinner).addClass('active');
        for (let idx in global.controllerManager.controllers) {
          if (global.controllerManager.controllers[idx].state.team === totalWinner) {
            global.controllerManager.controllers[idx].sendData('vibrate', [200, 100, 100, 50, 600]);
          }
        }
        setTimeout(() => {
          $('.confetti-emitter').removeClass(totalWinner).removeClass('active');
        }, 3000);
      }
    }, 1750);
  }
}

function displayTotalPoints() {
  const rounds = $('.points.total .rounds .round');
  showRound(rounds);
}


function displayRoundPoints(id, steps = 1) {
  const rP = $(`#${id} .points .red`).data('points');
  const bP = $(`#${id} .points .blue`).data('points');

  function increasePoints() {
    const rCurPoints = Number.parseInt($(`#${id} .points .red`).html(), 10) + steps;
    const bCurPoints = Number.parseInt($(`#${id} .points .blue`).html(), 10) + steps;
    let rDone = false;
    let bDone = false;

    if (rCurPoints >= rP) {
      rDone = true;
      $(`#${id} .points .red`).html(rP);
    } else {
      $(`#${id} .points .red`).html(rCurPoints);
    }

    if (bCurPoints >= bP) {
      bDone = true;
      $(`#${id} .points .blue`).html(bP);
    } else {
      $(`#${id} .points .blue`).html(bCurPoints);
    }

    if (!rDone || !bDone) {
      setTimeout(increasePoints, 75);
    } else {
      if (rP !== bP) {
        const winningTeam = rP > bP ? 'red' : 'blue';
        for (let idx in global.controllerManager.controllers) {
          if (global.controllerManager.controllers[idx].state.team === winningTeam) {
            global.controllerManager.controllers[idx].sendData('vibrate', [200, 100, 100, 50, 600]);
          }
        }
      }
    }
  }
  setTimeout(increasePoints, 75);
}

module.exports = {
  displayTotalPoints,
  displayRoundPoints,
};
