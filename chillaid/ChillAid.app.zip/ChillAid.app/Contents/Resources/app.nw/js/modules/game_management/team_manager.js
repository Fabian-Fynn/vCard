class TeamManager {
  constructor() {
    this.teams = {
      red: {
        key: 'red',
        members: [],
        color: { r: 211, g: 47, b: 47 },
        globalScore: 0,
        localScore: 0,
        availableSprites: ['max_pony', 'max_hat', 'max_scarf', 'max_shorts'],
      },
      blue: {
        key: 'blue',
        members: [],
        color: { r: 3, g: 169, b: 244 },
        globalScore: 0,
        localScore: 0,
        availableSprites: ['max_pony', 'max_hat', 'max_scarf', 'max_shorts'],
      },
    };
    this.teamMinimumReached(1);
  }

  add(id, team) {
    if (typeof this.teams[team] === 'undefined') {
      return false;
    }
    if (this.teams[team].members.indexOf(id) > -1) {
      return true;
    }
    const leftTeam = this.remove(id);
    if (typeof this.teams[team] !== 'undefined' && this.teams[team].members.length < 4) {
      const ctrl = global.controllerManager.get(id);
      ctrl.sprite = this.teams[team].availableSprites.splice(
        Math.floor(Math.random() * this.teams[team].availableSprites.length),
        1
      )[0];
      this.teams[team].members.push(id);
      this.teamMinimumReached(1);
      if (leftTeam) {
        notify.enqueue({
          message: `switched to team ${team}`,
          controllerId: id,
          type: 'player',
        });
      } else {
        notify.enqueue({
          message: `joined team ${team}`,
          controllerId: id,
          type: 'player',
        });
        if (ctrl.menuController) {
          notify.enqueue(`${ctrl.state.name} has menu control`);
        }
      }
      return true;
    }
    return false;
  }


  remove(id) {
    for (let idx in this.teams) {
      if (this.teams[idx].members.indexOf(id) > -1) {
        const i = this.teams[idx].members.indexOf(id);
        if (typeof i === 'number' && i > -1) {
          this.teams[idx].availableSprites.push(global.controllerManager.get(id).sprite);
          this.teams[idx].members.splice(i, 1);
          this.teamMinimumReached(1);
          return true;
        }
      }
    }
    return false;
  }


  getTeams() {
    return $.extend({}, this.teams);
  }

  teamMinimumReached(min) {
    for (let idx in this.teams) {
      if (this.teams[idx].members.length < min) {
        $('#startGame').attr('disabled', true);
        return false;
      }
    }
    $('#startGame').attr('disabled', false);
    return true;
  }
}

module.exports = new TeamManager();
