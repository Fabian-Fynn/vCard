function init() {
  $('.select-btn').click((e) => {
    const group = $(e.delegateTarget).data('selectgroup');
    $(`.select-btn[data-selectgroup="${group}"]`).removeClass('active');
    $(e.delegateTarget).addClass('active');
  });
}

module.exports = Object.freeze({
  init,
});
