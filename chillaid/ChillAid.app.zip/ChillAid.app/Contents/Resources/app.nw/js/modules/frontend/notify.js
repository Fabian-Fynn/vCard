class Notifier {
  constructor() {
    this.queue = [];
    this.isVisible = false;
    this.displayTime = 1500;
  }

  enqueue(message) {
    if (typeof message === 'string') {
      this.queue.push(message);
    } else {
      switch (message.type) {
        case 'player':
          this.queue.push(this.parsePlayerMessage(message));
          break;
        default:
          this.queue.push(this.parseMessage(message));
      }
    }
    if (!this.isVisible) {
      this.displayNext();
    }
  }

  parsePlayerMessage(mObj) {
    const playerName = global.controllerManager.get(mObj.controllerId).state.name;
    return `${playerName} ${mObj.message}`;
  }

  parseMessage(mObj) {
    return mObj.message;
  }

  showNotification($note) {
    $note.addClass('visible');
    setTimeout(() => {
      this.isVisible = false;
      this.hideNotification($note);
    }, this.displayTime);
  }

  hideNotification($note) {
    $note.removeClass('visible');
    setTimeout(() => {
      this.displayNext();
    }, this.displayTime / 2);
  }

  displayNext() {
    const $note = $('#notification');
    const message = this.queue.splice(0, 1)[0];

    if (!this.isVisible && message) {
      this.isVisible = true;
      $note[0].innerHTML = message;
      this.showNotification($note);
    }
  }
}

const nfi = new Notifier();

global.notify = nfi;

module.exports = nfi;
