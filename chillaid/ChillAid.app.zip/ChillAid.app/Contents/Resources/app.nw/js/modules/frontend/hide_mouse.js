function init() {
  let to = setTimeout(hideMouse, 1500);
  addMouseMoveHandler();

  function hideMouse() {
    $('body').addClass('hide-mouse');
  }

  function addMouseMoveHandler() {
    $(global.w).on('mousemove', handleMouseMove);
  }

  function handleMouseMove() {
    $(global.w).off('mousemove', handleMouseMove);
    clearTimeout(to);

    $('body').removeClass('hide-mouse');
    to = setTimeout(hideMouse, 1500);
    setTimeout(addMouseMoveHandler, 75);
  }
}

module.exports = init;
