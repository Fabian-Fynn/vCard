function init() {
  const $menus = $('.unit.game .ingame-menu');
  $menus.click((e) => {
    if ($(e.target).is('.items, .items div')) {
      return;
    }
    $(e.delegateTarget).toggleClass('active');
  });
  $menus.find('.end-round').click(() => {
    if (global.gm.activeGame !== null) {
      global.gm.activeGame.game.paused = true;
      global.gm.activeGame.end();
    }
    $menus.removeClass('active');
  });
  $menus.find('.end-game').click(() => {
    global.gm.gameQueue = [];
    if (global.gm.activeGame !== null) {
      global.gm.activeGame.game.paused = true;
      global.gm.activeGame.end();
    }
    $menus.removeClass('active');
  });
}

module.exports = {
  init,
};
