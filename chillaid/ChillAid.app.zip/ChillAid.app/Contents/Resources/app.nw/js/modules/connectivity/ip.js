const os = require('os');
const smallRef = '0.1.2.3.4.5.6.7.8.9.Q.R.S.T.U.V.W.X.Y.Z.#'.split('.');
const bigRef = 'A.B.C.D.E.F.G.H.I.J.K.L.M.N.O.P'.split('.');

function encodeIP(ip) {
  const parts = ip.split('.');
  let encodedIP = '';
  for (let i = 0; i < parts.length; i++) {
    const partInt = parts[i];
    if (partInt <= 20) {
      encodedIP += smallRef[partInt];
    } else {
      const first = Math.floor(partInt / 16);
      const second = partInt % 16;
      encodedIP += bigRef[first];
      encodedIP += bigRef[second];
    }
  }
  return encodedIP;
}

function getLocalIp() {
  const ifaces = os.networkInterfaces();
  let ret;

  Object.keys(ifaces).forEach((ifname) => {
    let alias = 0;

    ifaces[ifname].forEach((iface) => {
      if (iface.family !== 'IPv4' || iface.internal !== false) {
        return;
      }

      if (alias < 1) {
        ret = iface.address;
      }
      ++alias;
    });
  });
  return ret;
}

function getEncodedLocalIp() {
  return encodeIP(getLocalIp());
}

function isIp(ipaddress) {
  if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress))
  {
    return true;
  }
  return false;
}

module.exports = Object.freeze({
  getLocalIp,
  getEncodedLocalIp,
  isIp,
});
